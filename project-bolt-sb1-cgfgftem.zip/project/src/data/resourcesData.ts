export interface Resource {
  id: string;
  title: {
    en: string;
    te: string;
  };
  description: {
    en: string;
    te: string;
  };
  category: {
    en: string;
    te: string;
  };
  link: string;
  format: string;
  icon: string;
}

const resourcesData: Resource[] = [
  {
    id: 'emergency-kit-checklist',
    title: {
      en: 'Emergency Kit Checklist',
      te: 'అత్యవసర కిట్ చెక్‌లిస్ట్'
    },
    description: {
      en: 'A comprehensive checklist for preparing your emergency kit with essential items needed during disasters.',
      te: 'విపత్తుల సమయంలో అవసరమయ్యే అత్యవసర వస్తువులతో మీ అత్యవసర కిట్‌ను తయారు చేయడానికి సమగ్ర చెక్‌లిస్ట్.'
    },
    category: {
      en: 'Preparedness',
      te: 'సన్నద్ధత'
    },
    link: '/resources/emergency-kit-checklist.pdf',
    format: 'PDF',
    icon: 'FileBadge'
  },
  {
    id: 'evacuation-plan-template',
    title: {
      en: 'Family Evacuation Plan Template',
      te: 'కుటుంబ ఖాళీ ప్రణాళిక టెంప్లేట్'
    },
    description: {
      en: 'Template to create a customized evacuation plan for your family, including meeting points and emergency contacts.',
      te: 'మీటింగ్ పాయింట్లు మరియు అత్యవసర సంప్రదింపులతో సహా మీ కుటుంబానికి అనుకూలీకరించిన ఖాళీ ప్రణాళికను సృష్టించడానికి టెంప్లేట్.'
    },
    category: {
      en: 'Preparedness',
      te: 'సన్నద్ధత'
    },
    link: '/resources/family-evacuation-plan.pdf',
    format: 'PDF',
    icon: 'FileText'
  },
  {
    id: 'first-aid-guide',
    title: {
      en: 'Basic First Aid Guide',
      te: 'ప్రాథమిక ప్రథమ చికిత్స గైడ్'
    },
    description: {
      en: 'Learn basic first aid techniques for common emergency situations such as burns, fractures, and choking.',
      te: 'కాల్చడం, ఫ్రాక్చర్లు మరియు ఉక్కిరిబిక్కిరి వంటి సాధారణ అత్యవసర పరిస్థితుల కోసం ప్రాథమిక ప్రథమ చికిత్స పద్ధతులను నేర్చుకోండి.'
    },
    category: {
      en: 'Medical',
      te: 'వైద్య'
    },
    link: '/resources/first-aid-guide.pdf',
    format: 'PDF',
    icon: 'HeartPulse'
  },
  {
    id: 'flood-safety-guide',
    title: {
      en: 'Flood Safety Guide',
      te: 'వరద భద్రతా గైడ్'
    },
    description: {
      en: 'Detailed information on how to prepare for, respond to, and recover from floods in Hyderabad.',
      te: 'హైదరాబాద్‌లో వరదలకు ఎలా సిద్ధం కావాలి, ప్రతిస్పందించాలి మరియు కోలుకోవాలనే దానిపై వివరణాత్మక సమాచారం.'
    },
    category: {
      en: 'Disaster Specific',
      te: 'విపత్తు నిర్దిష్ట'
    },
    link: '/resources/flood-safety-guide.pdf',
    format: 'PDF',
    icon: 'Droplets'
  },
  {
    id: 'heat-wave-protection',
    title: {
      en: 'Heat Wave Protection Tips',
      te: 'వేడి గాలుల నుండి రక్షణ చిట్కాలు'
    },
    description: {
      en: 'Practical tips on staying safe during extreme heat conditions that are common in Hyderabad summers.',
      te: 'హైదరాబాద్ వేసవికాలంలో సాధారణంగా ఉండే తీవ్రమైన వేడి పరిస్థితులలో సురక్షితంగా ఉండటానికి ఆచరణాత్మక చిట్కాలు.'
    },
    category: {
      en: 'Disaster Specific',
      te: 'విపత్తు నిర్దిష్ట'
    },
    link: '/resources/heat-wave-protection.pdf',
    format: 'PDF',
    icon: 'Thermometer'
  },
  {
    id: 'water-purification',
    title: {
      en: 'Water Purification Methods',
      te: 'నీటి శుద్ధి పద్ధతులు'
    },
    description: {
      en: 'Simple and effective methods to purify water during emergencies when clean water is not available.',
      te: 'శుభ్రమైన నీరు అందుబాటులో లేనప్పుడు అత్యవసర పరిస్థితుల్లో నీటిని శుద్ధి చేయడానికి సరళమైన మరియు ప్రభావవంతమైన పద్ధతులు.'
    },
    category: {
      en: 'Health & Safety',
      te: 'ఆరోగ్యం & భద్రత'
    },
    link: '/resources/water-purification-guide.pdf',
    format: 'PDF',
    icon: 'Droplet'
  },
  {
    id: 'emergency-contacts-list',
    title: {
      en: 'Hyderabad Emergency Contacts List',
      te: 'హైదరాబాద్ అత్యవసర సంప్రదింపుల జాబితా'
    },
    description: {
      en: 'Printable list of all important emergency contacts in Hyderabad, including hospitals, fire stations, and police stations.',
      te: 'హైదరాబాద్‌లోని ఆసుపత్రులు, ఫైర్ స్టేషన్‌లు మరియు పోలీస్ స్టేషన్‌లతో సహా అన్ని ముఖ్యమైన అత్యవసర సంప్రదింపుల ముద్రించదగిన జాబితా.'
    },
    category: {
      en: 'Contacts',
      te: 'కాంటాక్ట్స్'
    },
    link: '/resources/hyderabad-emergency-contacts.pdf',
    format: 'PDF',
    icon: 'PhoneCall'
  },
  {
    id: 'mental-health-disaster',
    title: {
      en: 'Mental Health During Disasters',
      te: 'విపత్తుల సమయంలో మానసిక ఆరోగ్యం'
    },
    description: {
      en: 'Guide to managing stress, anxiety, and trauma during and after disaster situations.',
      te: 'విపత్తు పరిస్థితులలో మరియు తర్వాత ఒత్తిడి, ఆందోళన మరియు ట్రామాను నిర్వహించడానికి గైడ్.'
    },
    category: {
      en: 'Health & Safety',
      te: 'ఆరోగ్యం & భద్రత'
    },
    link: '/resources/mental-health-disasters.pdf',
    format: 'PDF',
    icon: 'Brain'
  }
];

export default resourcesData;