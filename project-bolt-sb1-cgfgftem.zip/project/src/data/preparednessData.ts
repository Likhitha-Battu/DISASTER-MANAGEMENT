interface LanguageContent {
  en: string;
  te: string;
}

interface PreparednessStep {
  id: number;
  icon: string;
  title: LanguageContent;
  content: LanguageContent;
}

interface PreparednessGuide {
  id: number;
  title: LanguageContent;
  description: LanguageContent;
  steps: {
    en: string[];
    te: string[];
  };
  image: string;
}

export const preparednessTips: PreparednessStep[] = [
  {
    id: 1,
    icon: 'Package',
    title: {
      en: 'Emergency Kit',
      te: 'అత్యవసర కిట్'
    },
    content: {
      en: 'Prepare a basic emergency kit with essential supplies to last at least 72 hours',
      te: 'కనీసం 72 గంటలు ఉండే అవసరమైన సరఫరాలతో ప్రాథమిక అత్యవసర కిట్‌ను సిద్ధం చేయండి'
    }
  },
  {
    id: 2,
    icon: 'Users',
    title: {
      en: 'Family Plan',
      te: 'కుటుంబ ప్రణాళిక'
    },
    content: {
      en: 'Create and practice a family emergency plan including meeting points and contact information',
      te: 'సమావేశ పాయింట్లు మరియు సంప్రదింపు సమాచారంతో సహా కుటుంబ అత్యవసర ప్రణాళికను సృష్టించి అభ్యాసం చేయండి'
    }
  },
  {
    id: 3,
    icon: 'Radio',
    title: {
      en: 'Stay Informed',
      te: 'సమాచారంతో ఉండండి'
    },
    content: {
      en: 'Keep a battery-powered radio and stay updated with local emergency broadcasts',
      te: 'బ్యాటరీతో నడిచే రేడియోను ఉంచండి మరియు స్థానిక అత్యవసర ప్రసారాలతో అప్‌డేట్‌గా ఉండండి'
    }
  },
  {
    id: 4,
    icon: 'FileText',
    title: {
      en: 'Important Documents',
      te: 'ముఖ్యమైన పత్రాలు'
    },
    content: {
      en: 'Keep copies of important documents in a waterproof container',
      te: 'ముఖ్యమైన పత్రాల కాపీలను వాటర్‌ప్రూఫ్ కంటైనర్‌లో ఉంచండి'
    }
  },
  {
    id: 5,
    icon: 'GraduationCap',
    title: {
      en: 'Learn Skills',
      te: 'నైపుణ్యాలు నేర్చుకోండి'
    },
    content: {
      en: 'Learn basic first aid and emergency response skills',
      te: 'ప్రాథమిక ప్రథమ చికిత్స మరియు అత్యవసర ప్రతిస్పందన నైపుణ్యాలను నేర్చుకోండి'
    }
  },
  {
    id: 6,
    icon: 'Home',
    title: {
      en: 'Home Safety',
      te: 'ఇంటి భద్రత'
    },
    content: {
      en: 'Secure your home against common disasters and know how to shut off utilities',
      te: 'సాధారణ విపత్తుల నుండి మీ ఇంటిని సురక్షితం చేయండి మరియు యుటిలిటీలను ఎలా ఆపాలో తెలుసుకోండి'
    }
  }
];

export const preparednessGuides: PreparednessGuide[] = [
  {
    id: 1,
    title: {
      en: 'Flood Preparedness',
      te: 'వరద సన్నద్ధత'
    },
    description: {
      en: 'Learn how to prepare for and respond to flooding, which is common during monsoon season in Hyderabad.',
      te: 'హైదరాబాద్‌లో వర్షాకాలంలో సాధారణంగా సంభవించే వరదలకు ఎలా సిద్ధం కావాలో మరియు ప్రతిస్పందించాలో తెలుసుకోండి.'
    },
    steps: {
      en: [
        'Keep important documents in waterproof containers',
        'Know your area\'s flood risk and evacuation routes',
        'Have emergency supplies ready',
        'Monitor local weather updates',
        'Move valuables to higher ground when flooding is expected'
      ],
      te: [
        'ముఖ్యమైన పత్రాలను వాటర్‌ప్రూఫ్ కంటైనర్లలో ఉంచండి',
        'మీ ప్రాంతం వరద ప్రమాదం మరియు ఖాళీ మార్గాలను తెలుసుకోండి',
        'అత్యవసర సరఫరాలను సిద్ధంగా ఉంచండి',
        'స్థానిక వాతావరణ అప్‌డేట్‌లను గమనించండి',
        'వరద వచ్చే అవకాశం ఉన్నప్పుడు విలువైన వస్తువులను ఎత్తైన ప్రదేశానికి తరలించండి'
      ]
    },
    image: 'https://images.pexels.com/photos/1756325/pexels-photo-1756325.jpeg'
  },
  {
    id: 2,
    title: {
      en: 'Heat Wave Safety',
      te: 'వేడి గాలుల భద్రత'
    },
    description: {
      en: 'Protect yourself and your family during extreme heat conditions that are common in Hyderabad summers.',
      te: 'హైదరాబాద్ వేసవిలో సాధారణంగా ఉండే తీవ్ర వేడి పరిస్థితుల్లో మిమ్మల్ని మరియు మీ కుటుంబాన్ని రక్షించుకోండి.'
    },
    steps: {
      en: [
        'Stay hydrated and drink plenty of water',
        'Avoid outdoor activities during peak heat hours',
        'Keep your home cool and well-ventilated',
        'Know the signs of heat exhaustion',
        'Check on elderly neighbors and vulnerable people'
      ],
      te: [
        'హైడ్రేటెడ్‌గా ఉండండి మరియు పుష్కలంగా నీరు త్రాగండి',
        'అత్యధిక వేడి సమయాల్లో బయటి కార్యకలాపాలను నివారించండి',
        'మీ ఇంటిని చల్లగా మరియు బాగా గాలి వచ్చేలా ఉంచండి',
        'వేడి అలసట సంకేతాలను తెలుసుకోండి',
        'వృద్ధ పొరుగువారు మరియు దుర్బల వ్యక్తులను తనిఖీ చేయండి'
      ]
    },
    image: 'https://images.pexels.com/photos/3873175/pexels-photo-3873175.jpeg'
  },
  {
    id: 3,
    title: {
      en: 'Emergency Communication',
      te: 'అత్యవసర కమ్యూనికేషన్'
    },
    description: {
      en: 'Establish and maintain emergency communication plans to stay connected with family during disasters.',
      te: 'విపత్తుల సమయంలో కుటుంబంతో అనుసంధానంగా ఉండటానికి అత్యవసర కమ్యూనికేషన్ ప్రణాళికలను ఏర్పాటు చేసి నిర్వహించండి.'
    },
    steps: {
      en: [
        'Create a family communication plan',
        'Keep emergency contact numbers readily available',
        'Have a backup battery-powered phone charger',
        'Identify an out-of-area contact person',
        'Practice your communication plan regularly'
      ],
      te: [
        'కుటుంబ కమ్యూనికేషన్ ప్రణాళికను సృష్టించండి',
        'అత్యవసర సంప్రదింపు నంబర్లను సులభంగా అందుబాటులో ఉంచండి',
        'బ్యాకప్ బ్యాటరీ-పవర్డ్ ఫోన్ ఛార్జర్‌ను కలిగి ఉండండి',
        'ప్రాంతం వెలుపల సంప్రదింపు వ్యక్తిని గుర్తించండి',
        'మీ కమ్యూనికేషన్ ప్లాన్‌ను క్రమం తప్పకుండా ప్రాక్టీస్ చేయండి'
      ]
    },
    image: 'https://images.pexels.com/photos/2882234/pexels-photo-2882234.jpeg'
  }
];