export interface EmergencyContact {
  id: string;
  category: {
    en: string;
    te: string;
  };
  contacts: {
    name: {
      en: string;
      te: string;
    };
    phone: string;
    address?: {
      en: string;
      te: string;
    };
    hours?: {
      en: string;
      te: string;
    };
  }[];
}

const emergencyContacts: EmergencyContact[] = [
  {
    id: 'emergency-numbers',
    category: {
      en: 'Emergency Numbers',
      te: 'అత్యవసర నంబర్లు'
    },
    contacts: [
      {
        name: {
          en: 'National Emergency Number',
          te: 'జాతీయ అత్యవసర నంబర్'
        },
        phone: '112'
      },
      {
        name: {
          en: 'Police',
          te: 'పోలీసు'
        },
        phone: '100'
      },
      {
        name: {
          en: 'Fire',
          te: 'అగ్ని'
        },
        phone: '101'
      },
      {
        name: {
          en: 'Ambulance',
          te: 'అంబులెన్స్'
        },
        phone: '108'
      },
      {
        name: {
          en: 'Disaster Management',
          te: 'విపత్తు నిర్వహణ'
        },
        phone: '1077'
      },
      {
        name: {
          en: 'Women Helpline',
          te: 'మహిళల హెల్ప్‌లైన్'
        },
        phone: '1098'
      }
    ]
  },
  {
    id: 'hospitals',
    category: {
      en: 'Hospitals',
      te: 'ఆసుపత్రులు'
    },
    contacts: [
      {
        name: {
          en: 'Gandhi Hospital',
          te: 'గాంధీ ఆసుపత్రి'
        },
        phone: '040-27505566',
        address: {
          en: 'Musheerabad, Secunderabad, Telangana 500003',
          te: 'ముషీరాబాద్, సికింద్రాబాద్, తెలంగాణ 500003'
        },
        hours: {
          en: '24 hours',
          te: '24 గంటలు'
        }
      },
      {
        name: {
          en: 'Osmania General Hospital',
          te: 'ఉస్మానియా జనరల్ హాస్పిటల్'
        },
        phone: '040-24600122',
        address: {
          en: 'Afzal Gunj, Hyderabad, Telangana 500012',
          te: 'అఫ్జల్ గంజ్, హైదరాబాద్, తెలంగాణ 500012'
        },
        hours: {
          en: '24 hours',
          te: '24 గంటలు'
        }
      },
      {
        name: {
          en: 'NIMS Hospital',
          te: 'నిమ్స్ ఆసుపత్రి'
        },
        phone: '040-23489000',
        address: {
          en: 'Punjagutta, Hyderabad, Telangana 500082',
          te: 'పంజాగుట్ట, హైదరాబాద్, తెలంగాణ 500082'
        },
        hours: {
          en: '24 hours',
          te: '24 గంటలు'
        }
      }
    ]
  },
  {
    id: 'government-agencies',
    category: {
      en: 'Government Agencies',
      te: 'ప్రభుత్వ సంస్థలు'
    },
    contacts: [
      {
        name: {
          en: 'Greater Hyderabad Municipal Corporation (GHMC)',
          te: 'గ్రేటర్ హైదరాబాద్ మునిసిపల్ కార్పొరేషన్ (జిహెచ్ఎంసి)'
        },
        phone: '040-21111111',
        address: {
          en: 'CC Complex, Tank Bund Road, Lower Tank Bund, Hyderabad, Telangana 500063',
          te: 'సిసి కాంప్లెక్స్, ట్యాంక్ బండ్ రోడ్, లోయర్ ట్యాంక్ బండ్, హైదరాబాద్, తెలంగాణ 500063'
        }
      },
      {
        name: {
          en: 'Telangana State Disaster Response and Fire Services Department',
          te: 'తెలంగాణ రాష్ట్ర విపత్తు ప్రతిస్పందన మరియు అగ్నిమాపక సేవల విభాగం'
        },
        phone: '040-23442944',
        address: {
          en: '1st Floor, Home Department Building, Secretariat, Hyderabad, Telangana 500022',
          te: '1వ అంతస్తు, హోమ్ డిపార్ట్‌మెంట్ బిల్డింగ్, సచివాలయం, హైదరాబాద్, తెలంగాణ 500022'
        }
      },
      {
        name: {
          en: 'Hyderabad Metropolitan Water Supply and Sewerage Board',
          te: 'హైదరాబాద్ మెట్రోపాలిటన్ వాటర్ సప్లై అండ్ సీవరేజ్ బోర్డ్'
        },
        phone: '040-23442844',
        address: {
          en: 'Khairatabad, Hyderabad, Telangana 500004',
          te: 'ఖైరతాబాద్, హైదరాబాద్, తెలంగాణ 500004'
        }
      }
    ]
  },
  {
    id: 'relief-organizations',
    category: {
      en: 'Relief Organizations',
      te: 'సహాయ సంస్థలు'
    },
    contacts: [
      {
        name: {
          en: 'Indian Red Cross Society - Telangana State Branch',
          te: 'ఇండియన్ రెడ్ క్రాస్ సొసైటీ - తెలంగాణ స్టేట్ బ్రాంచ్'
        },
        phone: '040-23261939',
        address: {
          en: 'Red Cross Bhavan, Adikmet, Hyderabad, Telangana 500044',
          te: 'రెడ్ క్రాస్ భవన్, ఆదిక్‌మెట్, హైదరాబాద్, తెలంగాణ 500044'
        }
      },
      {
        name: {
          en: 'Disaster Response Force',
          te: 'విపత్తు ప్రతిస్పందన బలగం'
        },
        phone: '1070',
        address: {
          en: 'Hyderabad, Telangana',
          te: 'హైదరాబాద్, తెలంగాణ'
        }
      }
    ]
  }
];

export default emergencyContacts;