export interface DisasterType {
  id: string;
  title: {
    en: string;
    te: string;
  };
  description: {
    en: string;
    te: string;
  };
  image: string;
  color: string;
  risks: {
    en: string[];
    te: string[];
  };
  preparedness: {
    en: string[];
    te: string[];
  };
  response: {
    en: string[];
    te: string[];
  };
  recovery: {
    en: string[];
    te: string[];
  };
}

const disasterTypes: DisasterType[] = [
  {
    id: 'floods',
    title: {
      en: 'Floods',
      te: 'వరదలు'
    },
    description: {
      en: 'Hyderabad experiences flooding mainly during the monsoon season (June to October). Heavy rainfall can cause the Musi River and various water bodies to overflow, affecting low-lying areas. In 2020, Hyderabad experienced one of its worst floods in recent history.',
      te: 'హైదరాబాద్‌లో ప్రధానంగా వర్షాకాలంలో (జూన్ నుండి అక్టోబర్) వరదలు సంభవిస్తాయి. భారీ వర్షాలు మూసీ నది మరియు వివిధ జలాశయాలు పొంగి, దిగువ ప్రాంతాలను ప్రభావితం చేస్తాయి. 2020లో, హైదరాబాద్ ఇటీవలి చరిత్రలో అత్యంత ఘోరమైన వరదలలో ఒకదానిని ఎదుర్కొంది.'
    },
    image: 'https://images.pexels.com/photos/1446076/pexels-photo-1446076.jpeg',
    color: '#0F4C81',
    risks: {
      en: [
        'Submerged roads and residential areas',
        'Damage to infrastructure',
        'Waterborne diseases',
        'Electrical hazards',
        'Water contamination'
      ],
      te: [
        'ముంపు రోడ్లు మరియు నివాస ప్రాంతాలు',
        'మౌలిక సదుపాయాలకు నష్టం',
        'నీటి ద్వారా వ్యాప్తి చెందే వ్యాధులు',
        'విద్యుత్ ప్రమాదాలు',
        'నీటి కాలుష్యం'
      ]
    },
    preparedness: {
      en: [
        'Monitor weather forecasts regularly',
        'Identify safe evacuation routes and emergency shelters',
        'Keep emergency supplies ready',
        'Elevate electrical appliances and valuable items',
        'Install flood barriers or sandbags if in a flood-prone area',
        'Clear drainage systems'
      ],
      te: [
        'వాతావరణ సూచనలను క్రమం తప్పకుండా పర్యవేక్షించండి',
        'సురక్షితమైన తరలింపు మార్గాలు మరియు అత్యవసర ఆశ్రయాలను గుర్తించండి',
        'అత్యవసర సరఫరాలను సిద్ధంగా ఉంచండి',
        'విద్యుత్ ఉపకరణాలు మరియు విలువైన వస్తువులను ఎత్తండి',
        'వరద పీడిత ప్రాంతంలో ఉంటే వరద అడ్డంకులు లేదా ఇసుక సంచులను ఏర్పాటు చేయండి',
        'డ్రైనేజీ వ్యవస్థలను శుభ్రం చేయండి'
      ]
    },
    response: {
      en: [
        'Move to higher ground immediately',
        'Avoid walking or driving through flood waters',
        'Stay away from electrical wires and poles',
        'Follow instructions from local authorities',
        'Call emergency services if needed'
      ],
      te: [
        'వెంటనే ఎత్తైన ప్రదేశానికి వెళ్లండి',
        'వరద నీటి గుండా నడవడం లేదా డ్రైవింగ్ చేయడం మానుకోండి',
        'విద్యుత్ తీగలు మరియు స్తంభాల నుండి దూరంగా ఉండండి',
        'స్థానిక అధికారుల సూచనలను పాటించండి',
        'అవసరమైతే అత్యవసర సేవలను పిలవండి'
      ]
    },
    recovery: {
      en: [
        'Return home only when authorities declare it safe',
        'Document damage through photos for insurance claims',
        'Clean and disinfect everything that got wet',
        'Check for structural damage before re-entering buildings',
        'Be alert for gas leaks, electrical issues, and contaminated water'
      ],
      te: [
        'అధికారులు సురక్షితమని ప్రకటించినప్పుడు మాత్రమే ఇంటికి తిరిగి వెళ్లండి',
        'బీమా క్లెయిమ్‌ల కోసం ఫోటోల ద్వారా నష్టాన్ని డాక్యుమెంట్ చేయండి',
        'తడిసిన ప్రతిదాన్ని శుభ్రం చేసి క్రిమిసంహారక చేయండి',
        'భవనాలలోకి మళ్లీ ప్రవేశించే ముందు నిర్మాణాత్మక నష్టాన్ని తనిఖీ చేయండి',
        'గ్యాస్ లీకులు, విద్యుత్ సమస్యలు మరియు కలుషితమైన నీటి కోసం అప్రమత్తంగా ఉండండి'
      ]
    }
  },
  {
    id: 'heat-waves',
    title: {
      en: 'Heat Waves',
      te: 'వేడి గాలులు'
    },
    description: {
      en: 'Hyderabad regularly experiences extreme heat during summer months (March to June), with temperatures often exceeding 40°C (104°F). Heat waves can pose serious health risks, particularly to vulnerable populations like the elderly, children, and those with pre-existing medical conditions.',
      te: 'హైదరాబాద్ వేసవి నెలల్లో (మార్చి నుండి జూన్) తరచుగా తీవ్రమైన వేడిని అనుభవిస్తుంది, ఉష్ణోగ్రతలు తరచుగా 40°C (104°F)ని మించిపోతాయి. వేడి గాలులు తీవ్రమైన ఆరోగ్య ప్రమాదాలను కలిగిస్తాయి, ముఖ్యంగా వృద్ధులు, పిల్లలు మరియు ఇప్పటికే వైద్య పరిస్థితులు ఉన్నవారి వంటి అత్యంత ప్రమాదకరమైన జనాభాకు.'
    },
    image: 'https://images.pexels.com/photos/210186/pexels-photo-210186.jpeg',
    color: '#E63946',
    risks: {
      en: [
        'Heat exhaustion and heat stroke',
        'Dehydration',
        'Exacerbation of existing medical conditions',
        'Increased risk of fire incidents',
        'Power outages due to high demand for cooling'
      ],
      te: [
        'వేడి అలసట మరియు వేడి స్ట్రోక్',
        'నీరసం',
        'ఇప్పటికే ఉన్న వైద్య పరిస్థితుల తీవ్రత',
        'అగ్ని ప్రమాదాల ప్రమాదం పెరుగుతుంది',
        'చల్లబరచడానికి అధిక డిమాండ్ కారణంగా విద్యుత్ నిలిపివేత'
      ]
    },
    preparedness: {
      en: [
        'Stay informed about weather forecasts and heat alerts',
        'Prepare cooling solutions at home (air conditioning, fans, etc.)',
        'Stock up on water and hydrating fluids',
        'Install window shades or reflective materials to reduce heat gain',
        'Plan outdoor activities for cooler times of day',
        'Check on vulnerable family members and neighbors'
      ],
      te: [
        'వాతావరణ సూచనలు మరియు వేడి హెచ్చరికల గురించి తెలుసుకోండి',
        'ఇంట్లో చల్లబరిచే పరిష్కారాలను సిద్ధం చేయండి (వాతానుకూలన, ఫ్యాన్‌లు, మొదలైనవి)',
        'నీరు మరియు హైడ్రేటింగ్ ద్రవాలను నిల్వ చేయండి',
        'వేడిని తగ్గించడానికి విండో షేడ్‌లు లేదా ప్రతిబింబించే వస్తువులను ఇన్‌స్టాల్ చేయండి',
        'రోజులో చల్లని సమయాల కోసం బయటి కార్యకలాపాలను ప్లాన్ చేయండి',
        'హానికరమైన కుటుంబ సభ్యులు మరియు పొరుగువారిని తనిఖీ చేయండి'
      ]
    },
    response: {
      en: [
        'Stay indoors in cool areas during peak heat hours',
        'Drink plenty of water, even if not thirsty',
        'Wear lightweight, light-colored, loose-fitting clothing',
        'Take cool showers or baths',
        'Use wet cloths on neck and wrists to cool down',
        'Seek medical help immediately for heat stroke symptoms'
      ],
      te: [
        'గరిష్ట వేడి గంటల్లో చల్లని ప్రాంతాల్లో ఇంట్లోనే ఉండండి',
        'దాహం లేకపోయినా పుష్కలంగా నీరు త్రాగండి',
        'తేలికైన, ప్రకాశవంతమైన రంగు, సడలిన దుస్తులు ధరించండి',
        'చల్లని షవర్లు లేదా స్నానాలు చేయండి',
        'చల్లబరచడానికి మెడపై మరియు మణికట్టుపై తడి గుడ్డలను ఉపయోగించండి',
        'హీట్ స్ట్రోక్ లక్షణాల కోసం వెంటనే వైద్య సహాయం పొందండి'
      ]
    },
    recovery: {
      en: [
        'Continue to hydrate even after the heat subsides',
        'Rest and recover in cool environments',
        'Monitor symptoms and seek medical attention if needed',
        'Check on affected community members',
        'Prepare for potential power outages with backup solutions'
      ],
      te: [
        'వేడి తగ్గిన తర్వాత కూడా హైడ్రేట్ చేయడం కొనసాగించండి',
        'చల్లని వాతావరణంలో విశ్రాంతి తీసుకుని కోలుకోండి',
        'లక్షణాలను పర్యవేక్షించండి మరియు అవసరమైతే వైద్య సహాయం పొందండి',
        'ప్రభావిత సమాజ సభ్యులను తనిఖీ చేయండి',
        'బ్యాకప్ పరిష్కారాలతో సంభావ్య విద్యుత్ అంతరాయాలకు సిద్ధంగా ఉండండి'
      ]
    }
  },
  {
    id: 'earthquakes',
    title: {
      en: 'Earthquakes',
      te: 'భూకంపాలు'
    },
    description: {
      en: 'While Hyderabad is not in a high seismic zone, it is classified as Zone II (low damage risk zone) according to India\'s seismic zoning map. Though rare, minor earthquakes have been recorded in the region. Being prepared is still important.',
      te: 'హైదరాబాద్ అధిక భూకంప మండలంలో లేనప్పటికీ, భారతదేశ భూకంప మండల పటం ప్రకారం ఇది జోన్ II (తక్కువ నష్ట ప్రమాదం మండలి)గా వర్గీకరించబడింది. అరుదైనప్పటికీ, ప్రాంతంలో చిన్న భూకంపాలు నమోదయ్యాయి. సిద్ధంగా ఉండటం ఇప్పటికీ ముఖ్యం.'
    },
    image: 'https://images.pexels.com/photos/726478/pexels-photo-726478.jpeg',
    color: '#2A9D8F',
    risks: {
      en: [
        'Building damage, especially to older structures',
        'Falling objects and debris',
        'Fire outbreaks from damaged gas lines',
        'Water line breaks and potential flooding',
        'Power outages'
      ],
      te: [
        'భవన నష్టం, ముఖ్యంగా పాత నిర్మాణాలకు',
        'పడిపోయే వస్తువులు మరియు శిథిలాలు',
        'డ్యామేజ్డ్ గ్యాస్ లైన్‌ల నుండి అగ్ని ప్రమాదాలు',
        'వాటర్ లైన్ బ్రేక్‌లు మరియు సంభావ్య వరదలు',
        'విద్యుత్ అంతరాయాలు'
      ]
    },
    preparedness: {
      en: [
        'Secure heavy furniture and appliances to walls',
        'Keep emergency supplies in an easily accessible location',
        'Identify safe spots in each room (under sturdy tables, against interior walls)',
        'Know how to shut off utilities',
        'Create a family emergency plan and meeting point',
        'Reinforce buildings according to safety standards if possible'
      ],
      te: [
        'భారీ ఫర్నిచర్ మరియు ఉపకరణాలను గోడలకు భద్రపరచండి',
        'అత్యవసర సరఫరాలను సులభంగా యాక్సెస్ చేయగల ప్రదేశంలో ఉంచండి',
        'ప్రతి గదిలో సురక్షితమైన స్థానాలను గుర్తించండి (పటిష్టమైన టేబుల్‌ల కింద, లోపలి గోడలకు వ్యతిరేకంగా)',
        'యుటిలిటీలను ఎలా మూసివేయాలో తెలుసుకోండి',
        'కుటుంబ అత్యవసర ప్రణాళిక మరియు కలిసే పాయింట్‌ను సృష్టించండి',
        'వీలైతే భద్రతా ప్రమాణాల ప్రకారం భవనాలను బలోపేతం చేయండి'
      ]
    },
    response: {
      en: [
        'Drop, cover, and hold on',
        'Stay away from windows, exterior walls, and heavy objects',
        'If indoors, stay there until shaking stops',
        'If outdoors, move to an open area away from buildings, trees, and power lines',
        'If in a vehicle, pull over safely away from structures and remain inside'
      ],
      te: [
        'పడిపో, కవర్ చేయి, మరియు పట్టుకో',
        'కిటికీలు, బయటి గోడలు మరియు భారీ వస్తువుల నుండి దూరంగా ఉండండి',
        'లోపల ఉన్నట్లయితే, కదలికలు ఆగే వరకు అక్కడే ఉండండి',
        'బయట ఉంటే, భవనాలు, చెట్లు మరియు విద్యుత్ లైన్‌ల నుండి దూరంగా బహిరంగ ప్రాంతానికి వెళ్లండి',
        'వాహనంలో ఉంటే, నిర్మాణాల నుండి సురక్షితంగా బయటకు తీసి లోపల ఉండండి'
      ]
    },
    recovery: {
      en: [
        'Check for injuries and provide first aid',
        'Inspect your home for damage, especially to utilities',
        'Be prepared for aftershocks',
        'Follow instructions from emergency services',
        'Help neighbors, especially those with special needs'
      ],
      te: [
        'గాయాల కోసం తనిఖీ చేసి ప్రాథమిక చికిత్స అందించండి',
        'మీ ఇంటిని నష్టం కోసం తనిఖీ చేయండి, ముఖ్యంగా ఉపయోగాలకు',
        'ఆఫ్టర్‌షాక్‌లకు సిద్ధంగా ఉండండి',
        'అత్యవసర సేవల నుండి సూచనలను పాటించండి',
        'పొరుగువారికి సహాయం చేయండి, ముఖ్యంగా ప్రత్యేక అవసరాలు ఉన్నవారికి'
      ]
    }
  },
  {
    id: 'fires',
    title: {
      en: 'Fires',
      te: 'అగ్ని ప్రమాదాలు'
    },
    description: {
      en: 'Urban fires are a concern in Hyderabad\'s densely populated areas, particularly in older neighborhoods with aging electrical systems and buildings that may not meet current fire safety standards. Both residential and commercial fires can spread quickly in congested areas.',
      te: 'హైదరాబాద్‌లోని జనసాంద్రత కలిగిన ప్రాంతాల్లో, ముఖ్యంగా పాతబడిన విద్యుత్ వ్యవస్థలు మరియు ప్రస్తుత అగ్ని భద్రతా ప్రమాణాలను పూర్తి చేయని భవనాలతో కూడిన పాత పరిసర ప్రాంతాల్లో నగర అగ్ని ప్రమాదాలు ఆందోళన కలిగిస్తాయి. నివాస మరియు వాణిజ్య మంటలు రెండూ రద్దీగా ఉన్న ప్రాంతాల్లో త్వరగా వ్యాపించవచ్చు.'
    },
    image: 'https://images.pexels.com/photos/433539/pexels-photo-433539.jpeg',
    color: '#F4A261',
    risks: {
      en: [
        'Smoke inhalation and burns',
        'Property damage and loss',
        'Structural collapse',
        'Electrical fires from faulty wiring',
        'Kitchen fires from unattended cooking'
      ],
      te: [
        'పొగ పీల్చడం మరియు కాల్చడం',
        'ఆస్తి నష్టం మరియు నష్టం',
        'నిర్మాణాత్మక కుప్పకూలడం',
        'లోపభూయిష్టమైన వైరింగ్ నుండి విద్యుత్ మంటలు',
        'శ్రద్ధ లేని వంట నుండి వంటగది మంటలు'
      ]
    },
    preparedness: {
      en: [
        'Install smoke detectors and fire extinguishers',
        'Create and practice a home evacuation plan',
        'Keep electrical systems maintained and avoid overloading outlets',
        'Store flammable materials safely',
        'Keep fire blankets in kitchens',
        'Ensure proper ventilation for gas appliances'
      ],
      te: [
        'స్మోక్ డిటెక్టర్‌లు మరియు అగ్నిమాపక యంత్రాలను ఇన్‌స్టాల్ చేయండి',
        'ఇంటి ఖాళీ ప్రణాళికను సృష్టించండి మరియు అభ్యాసం చేయండి',
        'విద్యుత్ వ్యవస్థలను నిర్వహించండి మరియు అవుట్‌లెట్‌లను ఓవర్‌లోడ్ చేయడం మానుకోండి',
        'మంటలు పట్టే వస్తువులను సురక్షితంగా నిల్వ చేయండి',
        'వంటగదుల్లో అగ్ని దుప్పట్లను ఉంచండి',
        'గ్యాస్ ఉపకరణాల కోసం సరైన వెంటిలేషన్‌ని నిర్ధారించండి'
      ]
    },
    response: {
      en: [
        'Alert others and evacuate immediately',
        'Call fire services (101)',
        'Use fire extinguishers only on small, contained fires',
        'Crawl low under smoke',
        'Close doors behind you to slow fire spread',
        'Once out, stay out - never re-enter a burning building'
      ],
      te: [
        'ఇతరులను హెచ్చరించండి మరియు వెంటనే ఖాళీ చేయండి',
        'ఫైర్ సర్వీసెస్‌కు కాల్ చేయండి (101)',
        'చిన్న, నియంత్రిత మంటలపై మాత్రమే అగ్నిమాపక యంత్రాలను ఉపయోగించండి',
        'పొగ కింద తక్కువగా పాకండి',
        'మంటల వ్యాప్తిని నెమ్మదించడానికి మీ వెనుక తలుపులు మూసివేయండి',
        'బయటకు వచ్చిన తర్వాత, బయటే ఉండండి - మండుతున్న భవనానికి ఎప్పుడూ తిరిగి ప్రవేశించవద్దు'
      ]
    },
    recovery: {
      en: [
        'Contact emergency services and insurance providers',
        'Document all damage',
        'Arrange for temporary housing if needed',
        'Have utilities inspected before turning them back on',
        'Clean smoke damage thoroughly',
        'Seek emotional support for trauma'
      ],
      te: [
        'అత్యవసర సేవలు మరియు బీమా ప్రొవైడర్‌లను సంప్రదించండి',
        'అన్ని నష్టాలను దస్తావేజు చేయండి',
        'అవసరమైతే తాత్కాలిక గృహాన్ని ఏర్పాటు చేయండి',
        'వాటిని తిరిగి ఆన్ చేయడానికి ముందు యుటిలిటీలను తనిఖీ చేయించండి',
        'పొగ నష్టాన్ని పూర్తిగా శుభ్రం చేయండి',
        'ట్రామా కోసం భావోద్వేగ మద్దతును కోరండి'
      ]
    }
  },
  {
    id: 'cyclones',
    title: {
      en: 'Cyclones',
      te: 'తుఫానులు'
    },
    description: {
      en: 'While Hyderabad is inland and less vulnerable to cyclones compared to coastal areas, the city can experience heavy rainfall, strong winds, and flooding as cyclonic systems move inland from the Bay of Bengal. These effects, while typically weaker than on the coast, can still cause significant disruption.',
      te: 'హైదరాబాద్ సముద్రతీర ప్రాంతాలతో పోలిస్తే లోపలి ప్రాంతంలో ఉంది మరియు తుఫానులకు తక్కువ దుర్బలంగా ఉంది, బంగాళాఖాతం నుండి తుఫాను వ్యవస్థలు లోపలికి కదులుతున్నప్పుడు నగరం భారీ వర్షపాతం, బలమైన గాలులు మరియు వరదలను ఎదుర్కొంటుంది. ఈ ప్రభావాలు, సాధారణంగా తీరంలో కంటే బలహీనంగా ఉన్నప్పటికీ, ఇప్పటికీ గణనీయమైన అంతరాయాన్ని కలిగించవచ్చు.'
    },
    image: 'https://images.pexels.com/photos/1446076/pexels-photo-1446076.jpeg',
    color: '#6C757D',
    risks: {
      en: [
        'Strong winds damaging structures and power lines',
        'Heavy rainfall leading to flooding',
        'Falling trees and debris',
        'Power outages',
        'Transportation disruptions'
      ],
      te: [
        'నిర్మాణాలు మరియు విద్యుత్ లైన్లను ధ్వంసం చేసే బలమైన గాలులు',
        'వరదలకు దారితీసే భారీ వర్షపాతం',
        'పడిపోయే చెట్లు మరియు శిథిలాలు',
        'విద్యుత్ నిలిపివేత',
        'రవాణా అంతరాయాలు'
      ]
    },
    preparedness: {
      en: [
        'Stay informed about weather forecasts and cyclone warnings',
        'Secure loose items outside your home',
        'Trim trees near your property to prevent falling branches',
        'Keep emergency supplies ready',
        'Know evacuation routes if in a flood-prone area',
        'Keep important documents in waterproof containers'
      ],
      te: [
        'వాతావరణ సూచనలు మరియు తుఫాను హెచ్చరికల గురించి తెలుసుకోండి',
        'మీ ఇంటి బయట సడలిన వస్తువులను భద్రపరచండి',
        'పడిపోయే కొమ్మలను నివారించడానికి మీ ఆస్తి సమీపంలోని చెట్లను కత్తిరించండి',
        'అత్యవసర సరఫరాలను సిద్ధంగా ఉంచండి',
        'వరద ప్రవణ ప్రాంతంలో ఉంటే తరలింపు మార్గాలను తెలుసుకోండి',
        'ముఖ్యమైన పత్రాలను నీటి నిరోధక కంటైనర్లలో ఉంచండి'
      ]
    },
    response: {
      en: [
        'Stay indoors during the cyclone',
        'Keep away from windows and glass doors',
        'Use flashlights, not candles, if power goes out',
        'Follow emergency instructions from local authorities',
        'If ordered to evacuate, do so immediately'
      ],
      te: [
        'తుఫాను సమయంలో ఇంట్లోనే ఉండండి',
        'కిటికీలు మరియు గాజు తలుపుల నుండి దూరంగా ఉండండి',
        'విద్యుత్ పోతే కొవ్వొత్తులు కాకుండా ఫ్లాష్‌లైట్‌లను ఉపయోగించండి',
        'స్థానిక అధికారుల నుండి అత్యవసర సూచనలను పాటించండి',
        'తరలించమని ఆదేశిస్తే, వెంటనే అలా చేయండి'
      ]
    },
    recovery: {
      en: [
        'Check for damage to your property',
        'Beware of fallen power lines and report them',
        'Clean up debris safely',
        'Document damage for insurance purposes',
        'Help neighbors who may need assistance'
      ],
      te: [
        'మీ ఆస్తికి జరిగిన నష్టాన్ని తనిఖీ చేయండి',
        'పడిపోయిన విద్యుత్ లైన్ల గురించి జాగ్రత్తగా ఉండండి మరియు వాటిని రిపోర్ట్ చేయండి',
        'శిథిలాలను సురక్షితంగా శుభ్రపరచండి',
        'బీమా ప్రయోజనాల కోసం నష్టాన్ని డాక్యుమెంట్ చేయండి',
        'సహాయం అవసరమయ్యే పొరుగువారికి సహాయం చేయండి'
      ]
    }
  }
];

export default disasterTypes;