import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { AlertCircle, ChevronRight, Filter, Search } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import disasterTypes from '../data/disasterTypes';

const DisastersPage: React.FC = () => {
  const { t, language } = useLanguage();
  const [searchTerm, setSearchTerm] = useState('');

  const filteredDisasters = disasterTypes.filter(disaster => 
    disaster.title[language].toLowerCase().includes(searchTerm.toLowerCase()) ||
    disaster.description[language].toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="bg-neutral-50 min-h-screen">
      {/* Hero Section */}
      <section className="bg-primary-700 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl">
            <h1 className="text-3xl md:text-4xl font-bold mb-4">
              {t('nav.disasters')}
            </h1>
            <p className="text-primary-100 text-lg mb-6">
              Learn about the most common natural and man-made disasters that affect Hyderabad and how to prepare for them.
            </p>
            
            <div className="relative">
              <input
                type="text"
                placeholder={language === 'en' ? "Search disaster types..." : "ఆపద రకాలను శోధించండి..."}
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full py-3 px-4 pr-12 rounded-md text-neutral-800 focus:outline-none focus:ring-2 focus:ring-primary-300"
              />
              <Search className="absolute right-4 top-1/2 transform -translate-y-1/2 text-neutral-500 w-5 h-5" />
            </div>
          </div>
        </div>
      </section>

      {/* Disasters List */}
      <section className="py-12">
        <div className="container mx-auto px-4">
          {filteredDisasters.length === 0 ? (
            <div className="text-center py-12">
              <AlertCircle className="w-12 h-12 text-neutral-400 mx-auto mb-4" />
              <p className="text-neutral-600 text-lg">No disaster types found matching your search.</p>
              <button
                onClick={() => setSearchTerm('')}
                className="mt-4 text-primary-600 hover:text-primary-800 font-medium"
              >
                Clear search
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredDisasters.map((disaster) => (
                <Link 
                  key={disaster.id}
                  to={`/disasters/${disaster.id}`}
                  className="card group bg-white overflow-hidden transform transition duration-300 hover:-translate-y-2"
                >
                  <div className="relative h-48 overflow-hidden">
                    <img 
                      src={disaster.image} 
                      alt={disaster.title[language]} 
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                    />
                    <div 
                      className="absolute inset-0 opacity-60" 
                      style={{ backgroundColor: disaster.color }}
                    ></div>
                    <div className="absolute bottom-0 left-0 right-0 p-4">
                      <h3 className="text-white text-xl font-bold mb-1">
                        {disaster.title[language]}
                      </h3>
                    </div>
                  </div>
                  <div className="p-6">
                    <p className="text-neutral-600 mb-4 line-clamp-3">
                      {disaster.description[language]}
                    </p>
                    <div className="flex items-center text-primary-600 font-medium">
                      {language === 'en' ? 'Learn more' : 'మరింత తెలుసుకోండి'} <ChevronRight className="w-4 h-4 ml-1" />
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Information Section */}
      <section className="py-12 bg-primary-50">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto">
            <h2 className="text-2xl font-bold mb-6 text-neutral-900">
              {language === 'en' ? 'Understanding Disaster Risk in Hyderabad' : 'హైదరాబాద్‌లో విపత్తు ప్రమాదాన్ని అర్థం చేసుకోవడం'}
            </h2>
            <div className="prose prose-lg max-w-none">
              <p>
                {language === 'en' 
                  ? 'Hyderabad faces various disaster risks due to its geographic location, climate conditions, and urban development patterns. Understanding these risks is the first step toward effective preparedness.'
                  : 'హైదరాబాద్ దాని భౌగోళిక స్థానం, వాతావరణ పరిస్థితులు మరియు పట్టణ అభివృద్ధి నమూనాల కారణంగా వివిధ విపత్తు ప్రమాదాలను ఎదుర్కొంటుంది. ఈ ప్రమాదాలను అర్థం చేసుకోవడం సమర్థవంతమైన సన్నద్ధత వైపు మొదటి అడుగు.'}
              </p>
              <p>
                {language === 'en'
                  ? 'Each disaster type has unique characteristics, warning signs, and appropriate response strategies. By learning about potential hazards specific to your area, you can better protect yourself, your family, and your property.'
                  : 'ప్రతి విపత్తు రకానికి ప్రత్యేక లక్షణాలు, హెచ్చరిక సంకేతాలు మరియు తగిన ప్రతిస్పందన వ్యూహాలు ఉన్నాయి. మీ ప్రాంతానికి నిర్దిష్టమైన సంభావ్య ప్రమాదాల గురించి తెలుసుకోవడం ద్వారా, మీరు మిమ్మల్ని, మీ కుటుంబాన్ని మరియు మీ ఆస్తిని మెరుగ్గా రక్షించుకోవచ్చు.'}
              </p>
            </div>
            
            <div className="mt-8 bg-white p-6 rounded-lg shadow border-l-4 border-warning-500">
              <h3 className="text-xl font-bold mb-3 text-warning-700">
                {language === 'en' ? 'Assess Your Risk' : 'మీ రిస్క్‌ని అంచనా వేయండి'}
              </h3>
              <p className="mb-4 text-neutral-700">
                {language === 'en'
                  ? 'Take our personalized risk assessment to understand which disasters pose the greatest risk to your specific location in Hyderabad.'
                  : 'హైదరాబాద్‌లోని మీ నిర్దిష్ట ప్రాంతానికి ఏ విపత్తులు అత్యధిక ప్రమాదాన్ని కలిగిస్తాయో అర్థం చేసుకోవడానికి మా వ్యక్తిగతీకరించిన రిస్క్ అసెస్‌మెంట్‌ను తీసుకోండి.'}
              </p>
              <Link 
                to="/risk-assessment" 
                className="inline-flex items-center justify-center bg-warning-500 hover:bg-warning-600 text-white py-2 px-6 rounded-md font-medium transition-all"
              >
                {language === 'en' ? 'Start Risk Assessment' : 'రిస్క్ అసెస్‌మెంట్‌ను ప్రారంభించండి'}
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default DisastersPage;