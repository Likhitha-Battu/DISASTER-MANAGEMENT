import React, { useState } from 'react';
import { Search, Download, Filter, FileText, FileBadge, HeartPulse, Droplets, Thermometer, Droplet, PhoneCall, Brain } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import resourcesData from '../data/resourcesData';

const ResourcesPage: React.FC = () => {
  const { language } = useLanguage();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  // Get unique categories
  const categories = Array.from(
    new Set(resourcesData.map(resource => resource.category[language]))
  );

  // Filter resources based on search term and selected category
  const filteredResources = resourcesData.filter(resource => {
    const matchesSearch = 
      resource.title[language].toLowerCase().includes(searchTerm.toLowerCase()) ||
      resource.description[language].toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesCategory = selectedCategory 
      ? resource.category[language] === selectedCategory
      : true;

    return matchesSearch && matchesCategory;
  });

  // Function to render the appropriate icon based on icon string from data
  const renderIcon = (iconName: string) => {
    switch(iconName) {
      case 'FileBadge': return <FileBadge className="w-8 h-8" />;
      case 'FileText': return <FileText className="w-8 h-8" />;
      case 'HeartPulse': return <HeartPulse className="w-8 h-8" />;
      case 'Droplets': return <Droplets className="w-8 h-8" />;
      case 'Thermometer': return <Thermometer className="w-8 h-8" />;
      case 'Droplet': return <Droplet className="w-8 h-8" />;
      case 'PhoneCall': return <PhoneCall className="w-8 h-8" />;
      case 'Brain': return <Brain className="w-8 h-8" />;
      default: return <FileText className="w-8 h-8" />;
    }
  };

  return (
    <div className="bg-neutral-50 min-h-screen">
      {/* Hero Section */}
      <section className="bg-primary-700 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl">
            <h1 className="text-3xl md:text-4xl font-bold mb-4">
              {language === 'en' ? 'Emergency Resources' : 'అత్యవసర వనరులు'}
            </h1>
            <p className="text-primary-100 text-lg mb-6">
              {language === 'en' 
                ? 'Access emergency preparedness guides, checklists, and educational materials to help you before, during, and after disasters.' 
                : 'విపత్తులకు ముందు, సమయంలో మరియు తర్వాత మీకు సహాయపడే అత్యవసర సన్నద్ధత గైడ్‌లు, చెక్‌లిస్ట్‌లు మరియు విద్యా సామగ్రిని యాక్సెస్ చేయండి.'}
            </p>
            
            <div className="relative">
              <input
                type="text"
                placeholder={language === 'en' ? "Search resources..." : "వనరులను శోధించండి..."}
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full py-3 px-4 pr-12 rounded-md text-neutral-800 focus:outline-none focus:ring-2 focus:ring-primary-300"
              />
              <Search className="absolute right-4 top-1/2 transform -translate-y-1/2 text-neutral-500 w-5 h-5" />
            </div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-12">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row gap-8">
            {/* Category Filters */}
            <div className="md:w-1/4">
              <div className="bg-white rounded-lg shadow-md p-6 sticky top-4">
                <div className="flex items-center mb-4">
                  <Filter className="text-primary-600 w-5 h-5 mr-2" />
                  <h2 className="text-lg font-bold text-neutral-900">
                    {language === 'en' ? 'Categories' : 'వర్గాలు'}
                  </h2>
                </div>
                <ul className="space-y-2">
                  <li>
                    <button
                      onClick={() => setSelectedCategory(null)}
                      className={`w-full text-left px-3 py-2 rounded-md transition ${
                        selectedCategory === null 
                          ? 'bg-primary-100 text-primary-700 font-medium' 
                          : 'text-neutral-700 hover:bg-neutral-100'
                      }`}
                    >
                      {language === 'en' ? 'All Resources' : 'అన్ని వనరులు'}
                    </button>
                  </li>
                  {categories.map((category, index) => (
                    <li key={index}>
                      <button
                        onClick={() => setSelectedCategory(category)}
                        className={`w-full text-left px-3 py-2 rounded-md transition ${
                          selectedCategory === category 
                            ? 'bg-primary-100 text-primary-700 font-medium' 
                            : 'text-neutral-700 hover:bg-neutral-100'
                        }`}
                      >
                        {category}
                      </button>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
            
            {/* Resources List */}
            <div className="md:w-3/4">
              {filteredResources.length === 0 ? (
                <div className="bg-white rounded-lg shadow-md p-8 text-center">
                  <FileText className="w-16 h-16 text-neutral-300 mx-auto mb-4" />
                  <h2 className="text-xl font-medium text-neutral-700 mb-2">
                    {language === 'en' ? 'No resources found' : 'వనరులు కనుగొనబడలేదు'}
                  </h2>
                  <p className="text-neutral-500">
                    {language === 'en' 
                      ? 'Try adjusting your search or filter criteria.' 
                      : 'మీ శోధన లేదా ఫిల్టర్ ప్రమాణాలను సర్దుబాటు చేయడానికి ప్రయత్నించండి.'}
                  </p>
                  <button
                    onClick={() => {
                      setSearchTerm('');
                      setSelectedCategory(null);
                    }}
                    className="mt-4 text-primary-600 hover:text-primary-800 font-medium"
                  >
                    {language === 'en' ? 'Clear filters' : 'ఫిల్టర్‌లను క్లియర్ చేయండి'}
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {filteredResources.map((resource) => (
                    <div 
                      key={resource.id} 
                      className="bg-white rounded-lg shadow-md overflow-hidden transition-transform duration-300 hover:-translate-y-1"
                    >
                      <div className="flex p-6">
                        <div className="flex-shrink-0 w-16 h-16 bg-primary-100 text-primary-600 rounded-lg flex items-center justify-center mr-4">
                          {renderIcon(resource.icon)}
                        </div>
                        <div className="flex-grow">
                          <div className="flex items-center justify-between mb-2">
                            <h3 className="font-bold text-lg text-neutral-900">
                              {resource.title[language]}
                            </h3>
                            <span className="text-sm bg-primary-50 text-primary-700 px-2 py-1 rounded">
                              {resource.format}
                            </span>
                          </div>
                          <p className="text-neutral-600 text-sm mb-3">
                            {resource.description[language]}
                          </p>
                          <div className="flex items-center justify-between">
                            <span className="text-sm text-neutral-500">
                              {resource.category[language]}
                            </span>
                            <a 
                              href={resource.link}
                              className="inline-flex items-center text-primary-600 hover:text-primary-800 font-medium text-sm"
                              target="_blank"
                              rel="noopener noreferrer"
                            >
                              <Download className="w-4 h-4 mr-1" />
                              {language === 'en' ? 'Download' : 'డౌన్‌లోడ్'}
                            </a>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Additional Resources Section */}
      <section className="py-12 bg-primary-50">
        <div className="container mx-auto px-4">
          <h2 className="text-2xl font-bold mb-8 text-center text-neutral-900">
            {language === 'en' ? 'External Official Resources' : 'బాహ్య అధికారిక వనరులు'}
          </h2>
          <div className="max-w-4xl mx-auto bg-white rounded-lg shadow-md overflow-hidden">
            <div className="p-6">
              <h3 className="text-xl font-bold mb-4 text-neutral-900">
                {language === 'en' ? 'Government Resources' : 'ప్రభుత్వ వనరులు'}
              </h3>
              <ul className="space-y-4">
                <li className="p-4 border border-neutral-200 rounded-lg hover:bg-primary-50 transition">
                  <a href="https://ndma.gov.in/" target="_blank" rel="noopener noreferrer" className="flex justify-between items-center">
                    <div>
                      <h4 className="font-medium text-primary-700">
                        {language === 'en' ? 'National Disaster Management Authority (NDMA)' : 'జాతీయ విపత్తు నిర్వహణ సంస్థ (NDMA)'}
                      </h4>
                      <p className="text-sm text-neutral-600">
                        {language === 'en' ? 'Official guidelines, resources, and alerts from India\'s apex disaster management body' : 'భారతదేశ అత్యున్నత విపత్తు నిర్వహణ సంస్థ నుండి అధికారిక మార్గదర్శకాలు, వనరులు మరియు హెచ్చరికలు'}
                      </p>
                    </div>
                    <FileText className="w-5 h-5 text-neutral-400" />
                  </a>
                </li>
                <li className="p-4 border border-neutral-200 rounded-lg hover:bg-primary-50 transition">
                  <a href="https://www.telangana.gov.in/departments/revenue/telangana-state-disaster-management-authority" target="_blank" rel="noopener noreferrer" className="flex justify-between items-center">
                    <div>
                      <h4 className="font-medium text-primary-700">
                        {language === 'en' ? 'Telangana State Disaster Management Authority' : 'తెలంగాణ రాష్ట్ర విపత్తు నిర్వహణ సంస్థ'}
                      </h4>
                      <p className="text-sm text-neutral-600">
                        {language === 'en' ? 'State-level resources and information specific to Telangana' : 'తెలంగాణకు నిర్దిష్టమైన రాష్ట్ర స్థాయి వనరులు మరియు సమాచారం'}
                      </p>
                    </div>
                    <FileText className="w-5 h-5 text-neutral-400" />
                  </a>
                </li>
                <li className="p-4 border border-neutral-200 rounded-lg hover:bg-primary-50 transition">
                  <a href="https://www.ghmc.gov.in/" target="_blank" rel="noopener noreferrer" className="flex justify-between items-center">
                    <div>
                      <h4 className="font-medium text-primary-700">
                        {language === 'en' ? 'Greater Hyderabad Municipal Corporation (GHMC)' : 'గ్రేటర్ హైదరాబాద్ మునిసిపల్ కార్పొరేషన్ (GHMC)'}
                      </h4>
                      <p className="text-sm text-neutral-600">
                        {language === 'en' ? 'Local government resources, flood maps, and emergency services information' : 'స్థానిక ప్రభుత్వ వనరులు, వరద పటాలు మరియు అత్యవసర సేవల సమాచారం'}
                      </p>
                    </div>
                    <FileText className="w-5 h-5 text-neutral-400" />
                  </a>
                </li>
              </ul>
            </div>
            
            <div className="p-6 bg-neutral-50">
              <h3 className="text-xl font-bold mb-4 text-neutral-900">
                {language === 'en' ? 'Weather Information Resources' : 'వాతావరణ సమాచార వనరులు'}
              </h3>
              <ul className="space-y-4">
                <li className="p-4 bg-white border border-neutral-200 rounded-lg hover:bg-primary-50 transition">
                  <a href="https://mausam.imd.gov.in/" target="_blank" rel="noopener noreferrer" className="flex justify-between items-center">
                    <div>
                      <h4 className="font-medium text-primary-700">
                        {language === 'en' ? 'India Meteorological Department (IMD)' : 'భారత వాతావరణ శాఖ (IMD)'}
                      </h4>
                      <p className="text-sm text-neutral-600">
                        {language === 'en' ? 'Official weather forecasts, warnings, and radar imagery' : 'అధికారిక వాతావరణ సూచనలు, హెచ్చరికలు మరియు రాడార్ చిత్రాలు'}
                      </p>
                    </div>
                    <FileText className="w-5 h-5 text-neutral-400" />
                  </a>
                </li>
                <li className="p-4 bg-white border border-neutral-200 rounded-lg hover:bg-primary-50 transition">
                  <a href="https://www.imdhyderabad.gov.in/" target="_blank" rel="noopener noreferrer" className="flex justify-between items-center">
                    <div>
                      <h4 className="font-medium text-primary-700">
                        {language === 'en' ? 'IMD Hyderabad' : 'IMD హైదరాబాద్'}
                      </h4>
                      <p className="text-sm text-neutral-600">
                        {language === 'en' ? 'Hyderabad-specific weather information and forecasts' : 'హైదరాబాద్-నిర్దిష్ట వాతావరణ సమాచారం మరియు అంచనాలు'}
                      </p>
                    </div>
                    <FileText className="w-5 h-5 text-neutral-400" />
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default ResourcesPage;