import React from 'react';
import { Link } from 'react-router-dom';
import { BookOpen, Package, Users, Radio, FileText, GraduationCap, Home, Download, ChevronRight } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { preparednessGuides, preparednessTips } from '../data/preparednessData';

const PreparednessPage: React.FC = () => {
  const { t, language } = useLanguage();
  
  return (
    <div className="bg-neutral-50 min-h-screen">
      {/* Hero Section */}
      <section className="bg-safety-600 text-white py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl">
            <h1 className="text-3xl md:text-4xl font-bold mb-4">
              {language === 'en' ? 'Disaster Preparedness' : 'విపత్తు సన్నద్ధత'}
            </h1>
            <p className="text-safety-50 text-lg mb-0">
              {language === 'en' 
                ? 'Being prepared before a disaster strikes is your best defense. Learn how to protect yourself, your family, and your property.' 
                : 'విపత్తు సంభవించడానికి ముందు సిద్ధంగా ఉండటం మీ ఉత్తమ రక్షణ. మిమ్మల్ని, మీ కుటుంబాన్ని మరియు మీ ఆస్తిని ఎలా రక్షించుకోవాలో తెలుసుకోండి.'}
            </p>
          </div>
        </div>
      </section>

      {/* Key Preparedness Tips */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12 text-neutral-900">
            {language === 'en' ? 'Key Preparedness Steps' : 'ముఖ్యమైన సన్నద్ధత చర్యలు'}
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {preparednessTips.map((tip) => {
              // Map the icon string to the corresponding Lucide icon component
              let IconComponent: React.ElementType = Package;
              
              switch (tip.icon) {
                case 'Package': IconComponent = Package; break;
                case 'Users': IconComponent = Users; break;
                case 'Radio': IconComponent = Radio; break;
                case 'FileText': IconComponent = FileText; break;
                case 'GraduationCap': IconComponent = GraduationCap; break;
                case 'Home': IconComponent = Home; break;
                default: IconComponent = Package;
              }
              
              return (
                <div key={tip.id} className="bg-white rounded-lg shadow-md p-8 transition-transform duration-300 hover:-translate-y-1">
                  <div className="flex items-center justify-center w-16 h-16 bg-safety-100 text-safety-600 rounded-full mb-6 mx-auto">
                    <IconComponent className="w-8 h-8" />
                  </div>
                  <h3 className="text-xl font-bold mb-4 text-neutral-900 text-center">
                    {tip.title[language]}
                  </h3>
                  <p className="text-neutral-700 text-center">
                    {tip.content[language]}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Preparedness Guides */}
      <section className="py-16 bg-primary-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <BookOpen className="w-12 h-12 text-primary-600 mx-auto mb-4" />
            <h2 className="text-3xl font-bold text-neutral-900">
              {language === 'en' ? 'Preparedness Guides' : 'సన్నద్ధత గైడ్‌లు'}
            </h2>
          </div>
          
          <div className="space-y-12 max-w-4xl mx-auto">
            {preparednessGuides.map((guide) => (
              <div key={guide.id} className="bg-white rounded-lg shadow-md overflow-hidden">
                <div className="md:flex">
                  <div className="md:w-1/3">
                    <img 
                      src={guide.image} 
                      alt={guide.title[language]} 
                      className="w-full h-full object-cover object-center"
                      style={{ maxHeight: '300px' }}
                    />
                  </div>
                  <div className="md:w-2/3 p-6">
                    <h3 className="text-xl font-bold mb-3 text-neutral-900">
                      {guide.title[language]}
                    </h3>
                    <p className="text-neutral-700 mb-4">
                      {guide.description[language]}
                    </p>
                    <div className="mb-4">
                      <h4 className="font-medium text-neutral-900 mb-2">
                        {language === 'en' ? 'Key Steps:' : 'ముఖ్యమైన చర్యలు:'}
                      </h4>
                      <ul className="space-y-2 pl-5 list-disc text-neutral-700">
                        {guide.steps[language].slice(0, 3).map((step, index) => (
                          <li key={index}>{step}</li>
                        ))}
                      </ul>
                    </div>
                    <Link to={`/resources`} className="inline-flex items-center text-primary-700 hover:text-primary-800 font-medium">
                      <Download className="w-4 h-4 mr-1" />
                      {language === 'en' ? 'Download full guide' : 'పూర్తి గైడ్‌ని డౌన్‌లోడ్ చేయండి'}
                    </Link>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Family Plan Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto bg-white rounded-lg shadow-lg overflow-hidden">
            <div className="md:flex">
              <div className="md:w-1/2 p-8">
                <h2 className="text-2xl font-bold mb-4 text-neutral-900">
                  {language === 'en' ? 'Create a Family Emergency Plan' : 'కుటుంబ అత్యవసర ప్రణాళికను సృష్టించండి'}
                </h2>
                <p className="text-neutral-700 mb-6">
                  {language === 'en'
                    ? 'Having a plan in place ensures that your family knows what to do during an emergency. Download our template and customize it for your household.'
                    : 'ప్రణాళిక ఉండటం వల్ల అత్యవసర పరిస్థితిలో మీ కుటుంబం ఏమి చేయాలో తెలుసుకుంటుంది. మా టెంప్లేట్‌ను డౌన్‌లోడ్ చేసుకొని మీ ఇంటి కోసం అనుకూలీకరించండి.'}
                </p>
                <ul className="space-y-3 mb-6">
                  <li className="flex items-start">
                    <span className="inline-block w-5 h-5 bg-safety-100 text-safety-700 rounded-full flex-shrink-0 flex items-center justify-center mr-2 mt-0.5">1</span>
                    <span className="text-neutral-700">
                      {language === 'en'
                        ? 'Discuss how to prepare and respond to emergencies that are most likely to happen in your area'
                        : 'మీ ప్రాంతంలో సంభవించే అవకాశం ఉన్న అత్యవసర పరిస్థితులకు ఎలా సిద్ధం కావాలో మరియు ప్రతిస్పందించాలో చర్చించండి'}
                    </span>
                  </li>
                  <li className="flex items-start">
                    <span className="inline-block w-5 h-5 bg-safety-100 text-safety-700 rounded-full flex-shrink-0 flex items-center justify-center mr-2 mt-0.5">2</span>
                    <span className="text-neutral-700">
                      {language === 'en'
                        ? 'Identify responsibilities for each family member'
                        : 'ప్రతి కుటుంబ సభ్యునికి బాధ్యతలను గుర్తించండి'}
                    </span>
                  </li>
                  <li className="flex items-start">
                    <span className="inline-block w-5 h-5 bg-safety-100 text-safety-700 rounded-full flex-shrink-0 flex items-center justify-center mr-2 mt-0.5">3</span>
                    <span className="text-neutral-700">
                      {language === 'en'
                        ? 'Practice your plan with regular drills'
                        : 'క్రమం తప్పకుండా డ్రిల్స్‌తో మీ ప్రణాళికను ఆచరించండి'}
                    </span>
                  </li>
                </ul>
                <Link 
                  to="/resources" 
                  className="inline-flex items-center justify-center bg-safety-500 hover:bg-safety-600 text-white py-2 px-6 rounded-md font-medium transition-all transform hover:scale-105"
                >
                  <Download className="w-4 h-4 mr-2" />
                  {language === 'en' ? 'Download Plan Template' : 'ప్లాన్ టెంప్లేట్‌ను డౌన్‌లోడ్ చేసుకోండి'}
                </Link>
              </div>
              <div className="md:w-1/2 bg-safety-700 text-white p-8 flex flex-col justify-center">
                <h3 className="text-xl font-bold mb-4">
                  {language === 'en' ? 'Your Plan Should Include:' : 'మీ ప్లాన్‌లో ఇవి ఉండాలి:'}
                </h3>
                <ul className="space-y-4">
                  <li className="flex items-start">
                    <span className="inline-block w-6 h-6 rounded-full border-2 border-white flex-shrink-0 flex items-center justify-center mr-3 mt-0.5">✓</span>
                    <span>
                      {language === 'en' ? 'Emergency meeting places' : 'అత్యవసర సమావేశ ప్రదేశాలు'}
                    </span>
                  </li>
                  <li className="flex items-start">
                    <span className="inline-block w-6 h-6 rounded-full border-2 border-white flex-shrink-0 flex items-center justify-center mr-3 mt-0.5">✓</span>
                    <span>
                      {language === 'en' ? 'Evacuation routes' : 'ఖాళీ మార్గాలు'}
                    </span>
                  </li>
                  <li className="flex items-start">
                    <span className="inline-block w-6 h-6 rounded-full border-2 border-white flex-shrink-0 flex items-center justify-center mr-3 mt-0.5">✓</span>
                    <span>
                      {language === 'en' ? 'Emergency contact information' : 'అత్యవసర సంప్రదింపు సమాచారం'}
                    </span>
                  </li>
                  <li className="flex items-start">
                    <span className="inline-block w-6 h-6 rounded-full border-2 border-white flex-shrink-0 flex items-center justify-center mr-3 mt-0.5">✓</span>
                    <span>
                      {language === 'en' ? 'Communication strategy' : 'కమ్యూనికేషన్ వ్యూహం'}
                    </span>
                  </li>
                  <li className="flex items-start">
                    <span className="inline-block w-6 h-6 rounded-full border-2 border-white flex-shrink-0 flex items-center justify-center mr-3 mt-0.5">✓</span>
                    <span>
                      {language === 'en' ? 'Special needs considerations' : 'ప్రత్యేక అవసరాల పరిగణనలు'}
                    </span>
                  </li>
                  <li className="flex items-start">
                    <span className="inline-block w-6 h-6 rounded-full border-2 border-white flex-shrink-0 flex items-center justify-center mr-3 mt-0.5">✓</span>
                    <span>
                      {language === 'en' ? 'Pet evacuation plan' : 'పెంపుడు జంతువుల ఖాళీ ప్రణాళిక'}
                    </span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Risk Assessment CTA */}
      <section className="py-12 bg-primary-700 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-2xl font-bold mb-4">
            {language === 'en' ? 'Know Your Risk Level' : 'మీ రిస్క్ స్థాయిని తెలుసుకోండి'}
          </h2>
          <p className="max-w-2xl mx-auto mb-8 text-primary-100">
            {language === 'en'
              ? 'Take our personalized risk assessment to understand which disasters pose the greatest risk to your specific location in Hyderabad.'
              : 'హైదరాబాద్‌లోని మీ నిర్దిష్ట ప్రాంతానికి ఏ విపత్తులు అత్యధిక ప్రమాదాన్ని కలిగిస్తాయో అర్థం చేసుకోవడానికి మా వ్యక్తిగతీకరించిన రిస్క్ అసెస్‌మెంట్‌ను తీసుకోండి.'}
          </p>
          <Link 
            to="/risk-assessment" 
            className="inline-flex items-center justify-center bg-white text-primary-700 hover:bg-primary-50 py-3 px-8 rounded-md font-medium transition-all transform hover:scale-105"
          >
            {language === 'en' ? 'Start Risk Assessment' : 'రిస్క్ అసెస్‌మెంట్‌ను ప్రారంభించండి'}
            <ChevronRight className="w-5 h-5 ml-1" />
          </Link>
        </div>
      </section>
    </div>
  );
};

export default PreparednessPage;