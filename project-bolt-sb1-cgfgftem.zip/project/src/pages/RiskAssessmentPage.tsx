import React, { useState, useCallback, useEffect } from 'react';
import { ArrowRight, ArrowLeft, CheckCircle, X, AlertCircle } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import disasterTypes from '../data/disasterTypes';

interface Question {
  id: string;
  text: {
    en: string;
    te: string;
  };
  options: {
    value: number;
    text: {
      en: string;
      te: string;
    };
  }[];
  disasterTypes: string[];
}

interface Result {
  disasterId: string;
  score: number;
}

const RiskAssessmentPage: React.FC = () => {
  const { language } = useLanguage();
  const [currentStep, setCurrentStep] = useState(0);
  const [location, setLocation] = useState('');
  const [answers, setAnswers] = useState<{[key: string]: number}>({});
  const [results, setResults] = useState<Result[]>([]);
  const [showResults, setShowResults] = useState(false);
  const [isCalculating, setIsCalculating] = useState(false);

  // Memoize questions to prevent unnecessary recalculations
  const questions: Question[] = React.useMemo(() => [
    {
      id: 'location',
      text: {
        en: 'What area of Hyderabad do you live in?',
        te: 'మీరు హైదరాబాద్‌లోని ఏ ప్రాంతంలో నివసిస్తున్నారు?'
      },
      options: [
        { value: 3, text: { en: 'Near Musi River or water bodies', te: 'మూసీ నది లేదా నీటి వనరుల సమీపంలో' } },
        { value: 2, text: { en: 'Low-lying area', te: 'దిగువ ప్రాంతం' } },
        { value: 1, text: { en: 'Urban area away from water bodies', te: 'నీటి వనరుల నుండి దూరంగా పట్టణ ప్రాంతం' } },
        { value: 0, text: { en: 'Elevated area', te: 'ఎత్తైన ప్రాంతం' } }
      ],
      disasterTypes: ['floods', 'cyclones']
    },
    {
      id: 'building',
      text: {
        en: 'What type of building do you live in?',
        te: 'మీరు ఏ రకమైన భవనంలో నివసిస్తున్నారు?'
      },
      options: [
        { value: 3, text: { en: 'Old construction (15+ years) with visible cracks', te: 'పాత నిర్మాణం (15+ సంవత్సరాలు) కనిపించే పగుళ్లతో' } },
        { value: 2, text: { en: 'Old construction but well-maintained', te: 'పాత నిర్మాణం కానీ బాగా నిర్వహించబడింది' } },
        { value: 1, text: { en: 'New construction (less than 10 years old)', te: 'కొత్త నిర్మాణం (10 సంవత్సరాల కంటే తక్కువ వయస్సు)' } },
        { value: 0, text: { en: 'Modern building with earthquake-resistant features', te: 'భూకంప నిరోధక లక్షణాలతో ఆధునిక భవనం' } }
      ],
      disasterTypes: ['earthquakes', 'fires']
    },
    {
      id: 'waterDrainage',
      text: {
        en: 'How is the water drainage in your area during heavy rains?',
        te: 'భారీ వర్షాల సమయంలో మీ ప్రాంతంలో నీటి డ్రైనేజీ ఎలా ఉంటుంది?'
      },
      options: [
        { value: 3, text: { en: 'Very poor, water accumulates quickly', te: 'చాలా పేలవంగా, నీరు త్వరగా పేరుకుపోతుంది' } },
        { value: 2, text: { en: 'Poor, takes several hours to drain', te: 'పేలవంగా, డ్రైన్ చేయడానికి అనేక గంటలు పడుతుంది' } },
        { value: 1, text: { en: 'Moderate, occasional small puddles', te: 'మధ్యస్థంగా, అప్పుడప్పుడు చిన్న మడుగులు' } },
        { value: 0, text: { en: 'Good, water drains quickly', te: 'బాగుంది, నీరు త్వరగా బయటకు వెళుతుంది' } }
      ],
      disasterTypes: ['floods', 'cyclones']
    },
    {
      id: 'powerOutages',
      text: {
        en: 'How frequently do you experience power outages in summer?',
        te: 'వేసవిలో మీరు ఎంత తరచుగా విద్యుత్ నిలిపివేతలను అనుభవిస్తారు?'
      },
      options: [
        { value: 3, text: { en: 'Very frequently (several times a week)', te: 'చాలా తరచుగా (వారానికి పలుసార్లు)' } },
        { value: 2, text: { en: 'Frequently (once or twice a week)', te: 'తరచుగా (వారానికి ఒకటి లేదా రెండుసార్లు)' } },
        { value: 1, text: { en: 'Occasionally (few times a month)', te: 'అప్పుడప్పుడు (నెలకు కొన్నిసార్లు)' } },
        { value: 0, text: { en: 'Rarely or never', te: 'అరుదుగా లేదా ఎప్పుడూ లేదు' } }
      ],
      disasterTypes: ['heat-waves']
    },
    {
      id: 'fireProtection',
      text: {
        en: 'What fire protection measures do you have in your home?',
        te: 'మీ ఇంట్లో ఏ అగ్ని రక్షణ చర్యలు ఉన్నాయి?'
      },
      options: [
        { value: 3, text: { en: 'None', te: 'ఏదీ లేదు' } },
        { value: 2, text: { en: 'Smoke detectors only', te: 'స్మోక్ డిటెక్టర్లు మాత్రమే' } },
        { value: 1, text: { en: 'Smoke detectors and fire extinguisher', te: 'స్మోక్ డిటెక్టర్లు మరియు అగ్నిమాపక యంత్రం' } },
        { value: 0, text: { en: 'Comprehensive system (detectors, extinguishers, and evacuation plan)', te: 'సమగ్ర వ్యవస్థ (డిటెక్టర్లు, ఎక్స్టింగ్విషర్లు మరియు ఖాళీ ప్రణాళిక)' } }
      ],
      disasterTypes: ['fires']
    },
    {
      id: 'emergencyKit',
      text: {
        en: 'Do you have an emergency kit prepared?',
        te: 'మీరు అత్యవసర కిట్ సిద్ధం చేశారా?'
      },
      options: [
        { value: 3, text: { en: 'No emergency supplies', te: 'అత్యవసర సరఫరాలు లేవు' } },
        { value: 2, text: { en: 'A few items but not organized', te: 'కొన్ని వస్తువులు కానీ నిర్వహించబడలేదు' } },
        { value: 1, text: { en: 'Basic emergency kit', te: 'ప్రాథమిక అత్యవసర కిట్' } },
        { value: 0, text: { en: 'Comprehensive emergency kit for at least 3 days', te: 'కనీసం 3 రోజులకు సమగ్ర అత్యవసర కిట్' } }
      ],
      disasterTypes: ['floods', 'earthquakes', 'fires', 'heat-waves', 'cyclones']
    }
  ], []);

  const calculateResults = useCallback(() => {
    setIsCalculating(true);
    
    // Use requestAnimationFrame to prevent UI blocking
    requestAnimationFrame(() => {
      const disasterScores: {[key: string]: number} = {};
      
      // Initialize scores with optimized loop
      const disasters = disasterTypes.map(d => d.id);
      disasters.forEach(id => {
        disasterScores[id] = 0;
      });
      
      // Calculate scores with weighted impact
      Object.entries(answers).forEach(([questionId, answer]) => {
        const question = questions.find(q => q.id === questionId);
        if (question) {
          const weight = question.disasterTypes.length === 1 ? 2 : 1;
          question.disasterTypes.forEach(disasterId => {
            disasterScores[disasterId] += answer * weight;
          });
        }
      });

      // Normalize and prepare results in a single pass
      const maxScore = Math.max(...Object.values(disasterScores));
      const resultArray: Result[] = Object.entries(disasterScores).map(([disasterId, score]) => ({
        disasterId,
        score: Math.max(10, Math.min(100, Math.round((score / maxScore) * 100)))
      }));

      // Sort and update state
      const sortedResults = resultArray.sort((a, b) => b.score - a.score);
      setResults(sortedResults);
      setShowResults(true);
      setIsCalculating(false);
    });
  }, [answers, questions]);

  // Optimize disaster lookup
  const disasterMap = React.useMemo(() => {
    const map: {[key: string]: typeof disasterTypes[0]} = {};
    disasterTypes.forEach(disaster => {
      map[disaster.id] = disaster;
    });
    return map;
  }, []);

  const getDisasterById = useCallback((id: string) => {
    return disasterMap[id];
  }, [disasterMap]);

  const handleNext = () => {
    if (currentStep < questions.length) {
      setCurrentStep(currentStep + 1);
    } else {
      calculateResults();
    }
  };

  const handlePrevious = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleSelectAnswer = useCallback((value: number) => {
    setAnswers(prev => ({
      ...prev,
      [questions[currentStep].id]: value
    }));
  }, [currentStep, questions]);

  const getCurrentQuestion = useCallback(() => {
    return questions[currentStep];
  }, [currentStep, questions]);

  const getRiskLevel = useCallback((score: number) => {
    if (score >= 70) return { text: language === 'en' ? 'High Risk' : 'అధిక ప్రమాదం', color: 'text-alert-700', bg: 'bg-alert-100' };
    if (score >= 40) return { text: language === 'en' ? 'Moderate Risk' : 'మధ్యస్థ ప్రమాదం', color: 'text-warning-700', bg: 'bg-warning-100' };
    return { text: language === 'en' ? 'Low Risk' : 'తక్కువ ప్రమాదం', color: 'text-safety-700', bg: 'bg-safety-100' };
  }, [language]);

  const getProgressPercentage = useCallback(() => {
    return Math.round((currentStep / questions.length) * 100);
  }, [currentStep, questions.length]);

  const goToStart = useCallback(() => {
    setCurrentStep(0);
    setAnswers({});
    setResults([]);
    setShowResults(false);
  }, []);

  return (
    <div className="bg-neutral-50 min-h-screen">
      {/* Hero Section */}
      <section className="bg-primary-700 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto">
            <h1 className="text-3xl md:text-4xl font-bold mb-4 text-center">
              {language === 'en' ? 'Personal Disaster Risk Assessment' : 'వ్యక్తిగత విపత్తు ప్రమాద మదింపు'}
            </h1>
            <p className="text-primary-100 text-lg mb-0 text-center">
              {language === 'en' 
                ? 'Answer a few questions to assess your personal risk for different types of disasters in Hyderabad.' 
                : 'హైదరాబాద్‌లో వివిధ రకాల విపత్తుల కోసం మీ వ్యక్తిగత ప్రమాదాన్ని అంచనా వేయడానికి కొన్ని ప్రశ్నలకు సమాధానం ఇవ్వండి.'}
            </p>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-12">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto">
            {!showResults ? (
              <div className="bg-white rounded-lg shadow-md overflow-hidden">
                {/* Progress Bar */}
                <div className="w-full bg-neutral-100">
                  <div 
                    className="bg-primary-500 h-2 transition-all duration-300" 
                    style={{ width: `${getProgressPercentage()}%` }}
                  ></div>
                </div>
                
                <div className="p-8">
                  {/* Questions */}
                  {currentStep < questions.length ? (
                    <div className="animate-fade-in">
                      <h2 className="text-2xl font-bold mb-6 text-neutral-900">
                        {getCurrentQuestion().text[language]}
                      </h2>

                      <div className="space-y-4 mb-8">
                        {getCurrentQuestion().options.map((option, index) => (
                          <button
                            key={index}
                            onClick={() => handleSelectAnswer(option.value)}
                            className={`w-full p-4 text-left rounded-lg border-2 transition ${
                              answers[getCurrentQuestion().id] === option.value
                                ? 'border-primary-500 bg-primary-50'
                                : 'border-neutral-200 hover:border-primary-300'
                            }`}
                          >
                            <div className="flex items-center">
                              <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center mr-3 ${
                                answers[getCurrentQuestion().id] === option.value
                                  ? 'border-primary-500 bg-primary-500 text-white'
                                  : 'border-neutral-300'
                              }`}>
                                {answers[getCurrentQuestion().id] === option.value && (
                                  <CheckCircle className="w-4 h-4" />
                                )}
                              </div>
                              <span className={`${
                                answers[getCurrentQuestion().id] === option.value
                                  ? 'font-medium text-primary-700'
                                  : 'text-neutral-700'
                              }`}>
                                {option.text[language]}
                              </span>
                            </div>
                          </button>
                        ))}
                      </div>

                      <div className="flex justify-between">
                        <button
                          onClick={handlePrevious}
                          disabled={currentStep === 0}
                          className={`flex items-center ${
                            currentStep === 0
                              ? 'text-neutral-300 cursor-not-allowed'
                              : 'text-primary-600 hover:text-primary-800'
                          }`}
                        >
                          <ArrowLeft className="w-4 h-4 mr-2" />
                          {language === 'en' ? 'Previous' : 'మునుపటి'}
                        </button>

                        <button
                          onClick={handleNext}
                          disabled={!answers[getCurrentQuestion().id] && answers[getCurrentQuestion().id] !== 0}
                          className={`flex items-center ${
                            !answers[getCurrentQuestion().id] && answers[getCurrentQuestion().id] !== 0
                              ? 'bg-neutral-300 cursor-not-allowed text-white'
                              : 'bg-primary-600 hover:bg-primary-700 text-white'
                          } py-2 px-6 rounded-md`}
                        >
                          {language === 'en' ? 'Next' : 'తరువాయి'}
                          <ArrowRight className="w-4 h-4 ml-2" />
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="text-center py-8">
                      <h2 className="text-2xl font-bold mb-4 text-neutral-900">
                        {language === 'en' ? 'Calculating Your Risk Profile...' : 'మీ రిస్క్ ప్రొఫైల్‌ని లెక్కిస్తోంది...'}
                      </h2>
                      <div className="w-16 h-16 border-4 border-primary-500 border-t-transparent rounded-full animate-spin mx-auto"></div>
                      <p className="mt-4 text-neutral-600">
                        {language === 'en' ? 'This will only take a moment.' : 'ఇది క్షణం మాత్రమే పడుతుంది.'}
                      </p>
                    </div>
                  )}
                </div>
              </div>
            ) : (
              <div className="bg-white rounded-lg shadow-md animate-fade-in">
                <div className="p-8">
                  <h2 className="text-2xl font-bold mb-6 text-neutral-900 text-center">
                    {language === 'en' ? 'Your Personal Disaster Risk Assessment' : 'మీ వ్యక్తిగత విపత్తు ప్రమాద మదింపు'}
                  </h2>
                  
                  <p className="mb-8 text-neutral-600 text-center">
                    {language === 'en'
                      ? 'Based on your responses, here are your personal risk levels for different disaster types in Hyderabad:'
                      : 'మీ ప్రతిస్పందనల ఆధారంగా, హైదరాబాద్‌లో వివిధ విపత్తుల రకాల కోసం మీ వ్యక్తిగత ప్రమాద స్థాయిలు ఇక్కడ ఉన్నాయి:'}
                  </p>
                  
                  <div className="space-y-6 mb-8">
                    {results.slice(0, 5).map((result, index) => {
                      const disaster = getDisasterById(result.disasterId);
                      const riskLevel = getRiskLevel(result.score);
                      
                      if (!disaster) return null;
                      
                      return (
                        <div key={result.disasterId} className="border border-neutral-200 rounded-lg overflow-hidden">
                          <div className="flex items-center p-4 border-b border-neutral-200">
                            <div className="w-12 h-12 rounded-full" style={{ backgroundColor: disaster.color }}>
                              <div className="w-full h-full flex items-center justify-center text-white">
                                {index + 1}
                              </div>
                            </div>
                            <div className="ml-4">
                              <h3 className="font-bold text-lg text-neutral-900">
                                {disaster.title[language]}
                              </h3>
                              <div className={`inline-block px-3 py-1 rounded-full text-sm font-medium ${riskLevel.color} ${riskLevel.bg}`}>
                                {riskLevel.text}
                              </div>
                            </div>
                            <div className="ml-auto">
                              <div className="relative h-16 w-16">
                                <svg className="w-full h-full" viewBox="0 0 36 36">
                                  <path
                                    d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                                    fill="none"
                                    stroke="#E9ECEF"
                                    strokeWidth="3"
                                  />
                                  <path
                                    d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                                    fill="none"
                                    stroke={disaster.color}
                                    strokeWidth="3"
                                    strokeDasharray={`${result.score}, 100`}
                                  />
                                  <text x="18" y="21" textAnchor="middle" fontSize="10" fill="#343A40" fontWeight="bold">
                                    {result.score}%
                                  </text>
                                </svg>
                              </div>
                            </div>
                          </div>
                          <div className="p-4 bg-neutral-50">
                            <h4 className="font-medium mb-2 text-neutral-900">
                              {language === 'en' ? 'Key Recommendations:' : 'ముఖ్యమైన సిఫార్సులు:'}
                            </h4>
                            <ul className="space-y-2">
                              {result.score >= 70 ? (
                                <>
                                  <li className="flex items-start">
                                    <AlertCircle className="w-5 h-5 text-alert-500 mr-2 flex-shrink-0 mt-0.5" />
                                    <span className="text-neutral-700">
                                      {language === 'en'
                                        ? `Take immediate steps to prepare for ${disaster.title.en.toLowerCase()}`
                                        : `${disaster.title.te} కోసం సిద్ధం చేయడానికి వెంటనే చర్యలు తీసుకోండి`}
                                    </span>
                                  </li>
                                  <li className="flex items-start">
                                    <AlertCircle className="w-5 h-5 text-alert-500 mr-2 flex-shrink-0 mt-0.5" />
                                    <span className="text-neutral-700">
                                      {language === 'en'
                                        ? 'Create a detailed emergency plan for your household'
                                        : 'మీ ఇంటి కోసం వివరణాత్మక అత్యవసర ప్రణాళికను సృష్టించండి'}
                                    </span>
                                  </li>
                                </>
                              ) : result.score >= 40 ? (
                                <>
                                  <li className="flex items-start">
                                    <AlertCircle className="w-5 h-5 text-warning-500 mr-2 flex-shrink-0 mt-0.5" />
                                    <span className="text-neutral-700">
                                      {language === 'en'
                                        ? `Review and improve your preparedness for ${disaster.title.en.toLowerCase()}`
                                        : `${disaster.title.te} కోసం మీ సన్నద్ధతను సమీక్షించండి మరియు మెరుగుపరచండి`}
                                    </span>
                                  </li>
                                  <li className="flex items-start">
                                    <AlertCircle className="w-5 h-5 text-warning-500 mr-2 flex-shrink-0 mt-0.5" />
                                    <span className="text-neutral-700">
                                      {language === 'en'
                                        ? 'Assemble or update your emergency kit'
                                        : 'మీ అత్యవసర కిట్‌ను సమీకరించండి లేదా నవీకరించండి'}
                                    </span>
                                  </li>
                                </>
                              ) : (
                                <>
                                  <li className="flex items-start">
                                    <CheckCircle className="w-5 h-5 text-safety-500 mr-2 flex-shrink-0 mt-0.5" />
                                    <span className="text-neutral-700">
                                      {language === 'en'
                                        ? `Maintain your current level of preparedness for ${disaster.title.en.toLowerCase()}`
                                        : `${disaster.title.te} కోసం మీ ప్రస్తుత సన్నద్ధత స్థాయిని నిర్వహించండి`}
                                    </span>
                                  </li>
                                  <li className="flex items-start">
                                    <CheckCircle className="w-5 h-5 text-safety-500 mr-2 flex-shrink-0 mt-0.5" />
                                    <span className="text-neutral-700">
                                      {language === 'en'
                                        ? 'Stay informed about changing conditions'
                                        : 'మారుతున్న పరిస్థితుల గురించి సమాచారంతో ఉండండి'}
                                    </span>
                                  </li>
                                </>
                              )}
                            </ul>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                  
                  <div className="flex flex-col sm:flex-row gap-4 justify-center">
                    <button
                      onClick={goToStart}
                      className="bg-neutral-100 hover:bg-neutral-200 text-neutral-800 py-2 px-6 rounded-md font-medium transition-all"
                    >
                      <X className="w-4 h-4 inline mr-2" />
                      {language === 'en' ? 'Restart Assessment' : 'అసెస్‌మెంట్‌ను పునఃప్రారంభించండి'}
                    </button>
                    
                    <a
                      href="/resources"
                      className="bg-primary-600 hover:bg-primary-700 text-white py-2 px-6 rounded-md font-medium transition-all text-center"
                    >
                      {language === 'en' ? 'View Preparedness Resources' : 'సన్నద్ధత వనరులను వీక్షించండి'}
                    </a>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Disclaimer */}
      {showResults && (
        <section className="py-8">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl mx-auto bg-neutral-50 border border-neutral-200 rounded-lg p-6">
              <h3 className="text-lg font-bold mb-2 text-neutral-900">
                {language === 'en' ? 'Disclaimer' : 'డిస్‌క్లెయిమర్'}
              </h3>
              <p className="text-sm text-neutral-700">
                {language === 'en'
                  ? 'This risk assessment is provided for informational purposes only and is based on the limited information you provided. It does not guarantee safety and should not replace professional assessment or advice from emergency management authorities. Always follow official guidance during emergencies.'
                  : 'ఈ రిస్క్ అసెస్‌మెంట్ కేవలం సమాచార ప్రయోజనాల కోసం అందించబడింది మరియు మీరు అందించిన పరిమిత సమాచారం ఆధారంగా ఉంటుంది. ఇది భద్రతకు హామీ ఇవ్వదు మరియు అత్యవసర నిర్వహణ అధికారుల నుండి వృత్తిపరమైన మదింపు లేదా సలహాను భర్తీ చేయకూడదు. అత్యవసర పరిస్థితుల్లో ఎల్లప్పుడూ అధికారిక మార్గదర్శకత్వాన్ని పాటించండి.'}
              </p>
            </div>
          </div>
        </section>
      )}
    </div>
  );
};

export default RiskAssessmentPage;