import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, Shield, AlertCircle, Repeat, ListChecks } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import disasterTypes, { DisasterType } from '../data/disasterTypes';

const DisasterDetailPage: React.FC = () => {
  const { disasterId } = useParams<{ disasterId: string }>();
  const { language } = useLanguage();
  const [disaster, setDisaster] = useState<DisasterType | null>(null);
  const [activeTab, setActiveTab] = useState<'preparedness' | 'response' | 'recovery'>('preparedness');

  useEffect(() => {
    const foundDisaster = disasterTypes.find(d => d.id === disasterId);
    setDisaster(foundDisaster || null);
    
    // Scroll to top when disaster changes
    window.scrollTo(0, 0);
  }, [disasterId]);

  if (!disaster) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <AlertCircle className="w-16 h-16 text-alert-500 mx-auto mb-4" />
          <h2 className="text-2xl font-bold mb-2">Disaster not found</h2>
          <p className="text-neutral-600 mb-6">The disaster information you're looking for does not exist or has been moved.</p>
          <Link to="/disasters" className="btn btn-primary">
            View All Disasters
          </Link>
        </div>
      </div>
    );
  }

  const handleTabChange = (tab: 'preparedness' | 'response' | 'recovery') => {
    setActiveTab(tab);
  };

  return (
    <div className="bg-neutral-50 min-h-screen">
      {/* Hero Section */}
      <section 
        className="relative py-20 text-white" 
        style={{ backgroundColor: disaster.color }}
      >
        <div className="absolute inset-0 bg-black opacity-40"></div>
        <div 
          className="absolute inset-0 bg-cover bg-center" 
          style={{ 
            backgroundImage: `url('${disaster.image}')`,
            filter: "brightness(0.7)"
          }}
        ></div>
        <div className="container mx-auto px-4 relative z-10">
          <Link to="/disasters" className="inline-flex items-center text-white mb-6 transition hover:text-primary-100">
            <ArrowLeft className="w-5 h-5 mr-2" /> 
            {language === 'en' ? 'Back to all disasters' : 'అన్ని విపత్తులకు తిరిగి'}
          </Link>
          <h1 className="text-4xl md:text-5xl font-bold mb-4">
            {disaster.title[language]}
          </h1>
          <p className="text-xl max-w-2xl opacity-90">
            {disaster.description[language]}
          </p>
        </div>
      </section>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-12">
        <div className="flex flex-col lg:flex-row gap-12">
          {/* Main Content Area */}
          <div className="lg:w-2/3">
            {/* Tabs */}
            <div className="mb-8 border-b border-neutral-200">
              <div className="flex flex-wrap -mb-px">
                <button
                  className={`inline-block py-4 px-6 border-b-2 font-medium text-lg ${
                    activeTab === 'preparedness' 
                      ? `border-safety-500 text-safety-700` 
                      : 'border-transparent text-neutral-500 hover:text-neutral-700'
                  }`}
                  onClick={() => handleTabChange('preparedness')}
                >
                  <div className="flex items-center">
                    <Shield className="w-5 h-5 mr-2" />
                    {language === 'en' ? 'Preparedness' : 'సన్నద్ధత'}
                  </div>
                </button>
                <button
                  className={`inline-block py-4 px-6 border-b-2 font-medium text-lg ${
                    activeTab === 'response' 
                      ? `border-alert-500 text-alert-700` 
                      : 'border-transparent text-neutral-500 hover:text-neutral-700'
                  }`}
                  onClick={() => handleTabChange('response')}
                >
                  <div className="flex items-center">
                    <AlertCircle className="w-5 h-5 mr-2" />
                    {language === 'en' ? 'Response' : 'ప్రతిస్పందన'}
                  </div>
                </button>
                <button
                  className={`inline-block py-4 px-6 border-b-2 font-medium text-lg ${
                    activeTab === 'recovery' 
                      ? `border-warning-500 text-warning-700` 
                      : 'border-transparent text-neutral-500 hover:text-neutral-700'
                  }`}
                  onClick={() => handleTabChange('recovery')}
                >
                  <div className="flex items-center">
                    <Repeat className="w-5 h-5 mr-2" />
                    {language === 'en' ? 'Recovery' : 'రికవరీ'}
                  </div>
                </button>
              </div>
            </div>

            {/* Tab Content */}
            <div className="bg-white rounded-lg shadow-md p-8">
              {activeTab === 'preparedness' && (
                <div className="animate-fade-in">
                  <h2 className="text-2xl font-bold mb-6 text-safety-700 flex items-center">
                    <Shield className="w-6 h-6 mr-2" />
                    {language === 'en' ? 'Preparedness Steps' : 'సన్నద్ధత చర్యలు'}
                  </h2>
                  <p className="mb-6 text-neutral-700">
                    {language === 'en'
                      ? `Being prepared before a ${disaster.title.en.toLowerCase()} occurs can significantly reduce its impact on you, your family, and your property.`
                      : `${disaster.title.te} సంభవించడానికి ముందు సిద్ధంగా ఉండటం వల్ల మీపై, మీ కుటుంబంపై మరియు మీ ఆస్తిపై దాని ప్రభావాన్ని గణనీయంగా తగ్గించవచ్చు.`}
                  </p>
                  <ul className="space-y-4">
                    {disaster.preparedness[language].map((step, index) => (
                      <li key={index} className="flex">
                        <div className="mr-4 flex-shrink-0">
                          <div className="flex items-center justify-center w-8 h-8 rounded-full bg-safety-100 text-safety-700 font-bold">
                            {index + 1}
                          </div>
                        </div>
                        <div className="text-neutral-700">{step}</div>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {activeTab === 'response' && (
                <div className="animate-fade-in">
                  <h2 className="text-2xl font-bold mb-6 text-alert-700 flex items-center">
                    <AlertCircle className="w-6 h-6 mr-2" />
                    {language === 'en' ? 'Response Actions' : 'ప్రతిస్పందన చర్యలు'}
                  </h2>
                  <p className="mb-6 text-neutral-700">
                    {language === 'en'
                      ? `During a ${disaster.title.en.toLowerCase()}, knowing how to respond can save lives and prevent injuries. Follow these critical steps.`
                      : `${disaster.title.te} సమయంలో, ఎలా ప్రతిస్పందించాలో తెలుసుకోవడం ప్రాణాలను కాపాడుతుంది మరియు గాయాలను నివారిస్తుంది. ఈ క్రిటికల్ స్టెప్స్ ని పాటించండి.`}
                  </p>
                  <ul className="space-y-4">
                    {disaster.response[language].map((step, index) => (
                      <li key={index} className="flex">
                        <div className="mr-4 flex-shrink-0">
                          <div className="flex items-center justify-center w-8 h-8 rounded-full bg-alert-100 text-alert-700 font-bold">
                            {index + 1}
                          </div>
                        </div>
                        <div className="text-neutral-700">{step}</div>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {activeTab === 'recovery' && (
                <div className="animate-fade-in">
                  <h2 className="text-2xl font-bold mb-6 text-warning-700 flex items-center">
                    <Repeat className="w-6 h-6 mr-2" />
                    {language === 'en' ? 'Recovery Guidelines' : 'రికవరీ మార్గదర్శకాలు'}
                  </h2>
                  <p className="mb-6 text-neutral-700">
                    {language === 'en'
                      ? `After a ${disaster.title.en.toLowerCase()}, the recovery process involves ensuring safety, assessing damage, and beginning the rebuilding process.`
                      : `${disaster.title.te} తర్వాత, రికవరీ ప్రక్రియలో భద్రతను నిర్ధారించడం, నష్టాన్ని అంచనా వేయడం మరియు పునర్నిర్మాణ ప్రక్రియను ప్రారంభించడం ఉంటుంది.`}
                  </p>
                  <ul className="space-y-4">
                    {disaster.recovery[language].map((step, index) => (
                      <li key={index} className="flex">
                        <div className="mr-4 flex-shrink-0">
                          <div className="flex items-center justify-center w-8 h-8 rounded-full bg-warning-100 text-warning-700 font-bold">
                            {index + 1}
                          </div>
                        </div>
                        <div className="text-neutral-700">{step}</div>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          </div>

          {/* Sidebar */}
          <div className="lg:w-1/3">
            {/* Risk Factors */}
            <div className="bg-white rounded-lg shadow-md p-6 mb-8">
              <h3 className="text-xl font-bold mb-4 text-neutral-900 flex items-center">
                <AlertCircle className="w-5 h-5 mr-2 text-alert-500" />
                {language === 'en' ? 'Risk Factors' : 'ప్రమాద కారకాలు'}
              </h3>
              <ul className="space-y-2">
                {disaster.risks[language].map((risk, index) => (
                  <li key={index} className="flex items-start">
                    <span className="inline-block w-2 h-2 bg-alert-500 rounded-full mt-2 mr-2"></span>
                    <span className="text-neutral-700">{risk}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Related Resources */}
            <div className="bg-white rounded-lg shadow-md p-6 mb-8">
              <h3 className="text-xl font-bold mb-4 text-neutral-900 flex items-center">
                <ListChecks className="w-5 h-5 mr-2 text-primary-500" />
                {language === 'en' ? 'Related Resources' : 'సంబంధిత వనరులు'}
              </h3>
              <ul className="space-y-4">
                <li>
                  <Link to="/resources" className="block p-3 border border-neutral-200 rounded hover:bg-primary-50 transition">
                    <span className="font-medium text-primary-700">
                      {language === 'en' 
                        ? `${disaster.title.en} Safety Guide` 
                        : `${disaster.title.te} భద్రతా గైడ్`}
                    </span>
                    <span className="block text-sm text-neutral-600 mt-1">PDF</span>
                  </Link>
                </li>
                <li>
                  <Link to="/preparedness" className="block p-3 border border-neutral-200 rounded hover:bg-primary-50 transition">
                    <span className="font-medium text-primary-700">
                      {language === 'en' 
                        ? 'Emergency Kit Checklist' 
                        : 'అత్యవసర కిట్ చెక్‌లిస్ట్'}
                    </span>
                    <span className="block text-sm text-neutral-600 mt-1">PDF</span>
                  </Link>
                </li>
                <li>
                  <Link to="/contacts" className="block p-3 border border-neutral-200 rounded hover:bg-primary-50 transition">
                    <span className="font-medium text-primary-700">
                      {language === 'en' 
                        ? 'Emergency Contact Numbers' 
                        : 'అత్యవసర సంప్రదింపు నంబర్లు'}
                    </span>
                    <span className="block text-sm text-neutral-600 mt-1">
                      {language === 'en' ? 'Directory' : 'డైరెక్టరీ'}
                    </span>
                  </Link>
                </li>
              </ul>
            </div>

            {/* Emergency Alert */}
            <div className="bg-alert-50 border-l-4 border-alert-500 rounded p-6">
              <h3 className="font-bold text-alert-700 mb-2">
                {language === 'en' ? 'Emergency?' : 'అత్యవసరమా?'}
              </h3>
              <p className="text-neutral-700 mb-4">
                {language === 'en' 
                  ? 'If you are currently experiencing this disaster, call emergency services immediately.' 
                  : 'మీరు ప్రస్తుతం ఈ విపత్తును ఎదుర్కొంటున్నట్లయితే, వెంటనే అత్యవసర సేవలకు కాల్ చేయండి.'}
              </p>
              <div className="font-bold text-alert-700 text-xl">
                {language === 'en' ? 'Emergency: 112' : 'అత్యవసరం: 112'}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DisasterDetailPage;