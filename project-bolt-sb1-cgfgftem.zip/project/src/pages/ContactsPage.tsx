import React, { useState } from 'react';
import { Search, Phone, MapPin, Clock, Building } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import emergencyContacts from '../data/emergencyContacts';

const ContactsPage: React.FC = () => {
  const { language } = useLanguage();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  // Filter contacts based on search term and selected category
  const filteredContacts = emergencyContacts.filter(category => {
    // If category filter is applied, show only that category
    if (selectedCategory && category.id !== selectedCategory) {
      return false;
    }

    // If search term exists, check if the category or any contact matches
    if (searchTerm) {
      const categoryMatches = category.category[language].toLowerCase().includes(searchTerm.toLowerCase());
      
      const contactsMatch = category.contacts.some(contact => 
        contact.name[language].toLowerCase().includes(searchTerm.toLowerCase()) ||
        contact.phone.includes(searchTerm) ||
        (contact.address && contact.address[language].toLowerCase().includes(searchTerm.toLowerCase()))
      );
      
      return categoryMatches || contactsMatch;
    }
    
    return true;
  });

  return (
    <div className="bg-neutral-50 min-h-screen">
      {/* Hero Section */}
      <section className="bg-primary-700 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl">
            <h1 className="text-3xl md:text-4xl font-bold mb-4">
              {language === 'en' ? 'Emergency Contacts' : 'అత్యవసర సంప్రదింపులు'}
            </h1>
            <p className="text-primary-100 text-lg mb-6">
              {language === 'en' 
                ? 'Find important contact information for emergency services, hospitals, and government agencies in Hyderabad.' 
                : 'హైదరాబాద్‌లోని అత్యవసర సేవలు, ఆసుపత్రులు మరియు ప్రభుత్వ సంస్థల కోసం ముఖ్యమైన సంప్రదింపు సమాచారాన్ని కనుగొనండి.'}
            </p>
            
            <div className="relative">
              <input
                type="text"
                placeholder={language === 'en' ? "Search emergency contacts..." : "అత్యవసర సంప్రదింపులను శోధించండి..."}
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full py-3 px-4 pr-12 rounded-md text-neutral-800 focus:outline-none focus:ring-2 focus:ring-primary-300"
              />
              <Search className="absolute right-4 top-1/2 transform -translate-y-1/2 text-neutral-500 w-5 h-5" />
            </div>
          </div>
        </div>
      </section>

      {/* Emergency Numbers Banner */}
      <section className="py-8 bg-alert-50">
        <div className="container mx-auto px-4">
          <div className="bg-white rounded-lg shadow-md p-6 border-l-4 border-alert-500">
            <h2 className="text-xl font-bold mb-4 text-alert-700">
              {language === 'en' ? 'Important Emergency Numbers' : 'ముఖ్యమైన అత్యవసర నంబర్లు'}
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="flex items-center p-3 bg-alert-50 rounded-md">
                <div className="flex-shrink-0 w-12 h-12 bg-alert-500 text-white rounded-full flex items-center justify-center mr-4">
                  <Phone className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-bold text-neutral-900">
                    {language === 'en' ? 'All Emergencies' : 'అన్ని అత్యవసర పరిస్థితులు'}
                  </h3>
                  <p className="text-2xl font-bold text-alert-700">112</p>
                </div>
              </div>
              <div className="flex items-center p-3 bg-alert-50 rounded-md">
                <div className="flex-shrink-0 w-12 h-12 bg-alert-500 text-white rounded-full flex items-center justify-center mr-4">
                  <Phone className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-bold text-neutral-900">
                    {language === 'en' ? 'Ambulance' : 'అంబులెన్స్'}
                  </h3>
                  <p className="text-2xl font-bold text-alert-700">108</p>
                </div>
              </div>
              <div className="flex items-center p-3 bg-alert-50 rounded-md">
                <div className="flex-shrink-0 w-12 h-12 bg-alert-500 text-white rounded-full flex items-center justify-center mr-4">
                  <Phone className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-bold text-neutral-900">
                    {language === 'en' ? 'Fire Services' : 'అగ్నిమాపక సేవలు'}
                  </h3>
                  <p className="text-2xl font-bold text-alert-700">101</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-12">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row gap-8">
            {/* Category Filters */}
            <div className="md:w-1/4">
              <div className="bg-white rounded-lg shadow-md p-6 sticky top-4">
                <h2 className="text-lg font-bold mb-4 text-neutral-900">
                  {language === 'en' ? 'Categories' : 'వర్గాలు'}
                </h2>
                <ul className="space-y-2">
                  <li>
                    <button
                      onClick={() => setSelectedCategory(null)}
                      className={`w-full text-left px-3 py-2 rounded-md transition ${
                        selectedCategory === null 
                          ? 'bg-primary-100 text-primary-700 font-medium' 
                          : 'text-neutral-700 hover:bg-neutral-100'
                      }`}
                    >
                      {language === 'en' ? 'All Categories' : 'అన్ని వర్గాలు'}
                    </button>
                  </li>
                  {emergencyContacts.map((category) => (
                    <li key={category.id}>
                      <button
                        onClick={() => setSelectedCategory(category.id)}
                        className={`w-full text-left px-3 py-2 rounded-md transition ${
                          selectedCategory === category.id 
                            ? 'bg-primary-100 text-primary-700 font-medium' 
                            : 'text-neutral-700 hover:bg-neutral-100'
                        }`}
                      >
                        {category.category[language]}
                      </button>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
            
            {/* Contacts List */}
            <div className="md:w-3/4">
              {filteredContacts.length === 0 ? (
                <div className="bg-white rounded-lg shadow-md p-8 text-center">
                  <Phone className="w-16 h-16 text-neutral-300 mx-auto mb-4" />
                  <h2 className="text-xl font-medium text-neutral-700 mb-2">
                    {language === 'en' ? 'No contacts found' : 'సంప్రదింపులు కనుగొనబడలేదు'}
                  </h2>
                  <p className="text-neutral-500">
                    {language === 'en' 
                      ? 'Try adjusting your search or filter criteria.' 
                      : 'మీ శోధన లేదా ఫిల్టర్ ప్రమాణాలను సర్దుబాటు చేయడానికి ప్రయత్నించండి.'}
                  </p>
                  <button
                    onClick={() => {
                      setSearchTerm('');
                      setSelectedCategory(null);
                    }}
                    className="mt-4 text-primary-600 hover:text-primary-800 font-medium"
                  >
                    {language === 'en' ? 'Clear filters' : 'ఫిల్టర్‌లను క్లియర్ చేయండి'}
                  </button>
                </div>
              ) : (
                <div className="space-y-8">
                  {filteredContacts.map((category) => (
                    <div key={category.id} className="bg-white rounded-lg shadow-md overflow-hidden">
                      <div className="p-4 bg-primary-700 text-white">
                        <h2 className="text-xl font-bold">{category.category[language]}</h2>
                      </div>
                      
                      <div className="p-6">
                        <div className="grid grid-cols-1 gap-6">
                          {category.contacts.map((contact, index) => (
                            <div 
                              key={index} 
                              className="border border-neutral-200 rounded-lg p-4 hover:border-primary-300 transition-colors"
                            >
                              <div className="flex items-start">
                                <Building className="w-6 h-6 text-primary-600 mr-3 mt-1" />
                                <div>
                                  <h3 className="font-bold text-lg text-neutral-900 mb-1">
                                    {contact.name[language]}
                                  </h3>
                                  
                                  <div className="flex items-center mb-2">
                                    <Phone className="w-4 h-4 text-neutral-500 mr-2" />
                                    <a 
                                      href={`tel:${contact.phone}`} 
                                      className="text-primary-700 hover:text-primary-800 font-medium"
                                    >
                                      {contact.phone}
                                    </a>
                                  </div>
                                  
                                  {contact.address && (
                                    <div className="flex items-start mb-2">
                                      <MapPin className="w-4 h-4 text-neutral-500 mr-2 mt-1" />
                                      <span className="text-neutral-700">
                                        {contact.address[language]}
                                      </span>
                                    </div>
                                  )}
                                  
                                  {contact.hours && (
                                    <div className="flex items-start">
                                      <Clock className="w-4 h-4 text-neutral-500 mr-2 mt-1" />
                                      <span className="text-neutral-700">
                                        {contact.hours[language]}
                                      </span>
                                    </div>
                                  )}
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Download Contacts */}
      <section className="py-12 bg-primary-50">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-2xl font-bold mb-4 text-neutral-900">
            {language === 'en' ? 'Keep Emergency Contacts Handy' : 'అత్యవసర సంప్రదింపులను అందుబాటులో ఉంచుకోండి'}
          </h2>
          <p className="max-w-2xl mx-auto mb-8 text-neutral-600">
            {language === 'en'
              ? 'Download and print this list of emergency contacts to keep in your home, vehicle, and emergency kit for quick access during disasters when internet or mobile services may be unavailable.'
              : 'ఇంటర్నెట్ లేదా మొబైల్ సేవలు అందుబాటులో లేని విపత్తుల సమయంలో త్వరిత యాక్సెస్ కోసం మీ ఇంట్లో, వాహనంలో మరియు అత్యవసర కిట్‌లో ఉంచడానికి అత్యవసర సంప్రదింపుల ఈ జాబితాను డౌన్‌లోడ్ చేసి ప్రింట్ చేయండి.'}
          </p>
          <a 
            href="/resources/hyderabad-emergency-contacts.pdf"
            className="inline-flex items-center justify-center bg-primary-600 hover:bg-primary-700 text-white py-3 px-8 rounded-md font-medium transition-all"
            target="_blank"
            rel="noopener noreferrer"
          >
            {language === 'en' ? 'Download Printable Contacts List' : 'ముద్రించదగిన కాంటాక్ట్స్ జాబితాను డౌన్‌లోడ్ చేయండి'}
          </a>
        </div>
      </section>
    </div>
  );
};

export default ContactsPage;