import React from 'react';
import { Link } from 'react-router-dom';
import { AlertTriangle, ChevronRight, Shield, BookOpen, Phone } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import disasterTypes from '../data/disasterTypes';

const HomePage: React.FC = () => {
  const { t, language } = useLanguage();
  const featuredDisasters = disasterTypes.slice(0, 3);

  const getWeatherUpdates = async () => {
    window.open('https://www.telangana.gov.in/news/alerts', '_blank');
  };

  return (
    <div className="bg-neutral-50">
      {/* Hero Section */}
      <section className="relative bg-primary-700 text-white py-20 overflow-hidden">
        <div className="absolute inset-0 bg-black opacity-30"></div>
        <div 
          className="absolute inset-0 bg-cover bg-center" 
          style={{ 
            backgroundImage: "url('https://images.pexels.com/photos/1446076/pexels-photo-1446076.jpeg')",
            filter: "brightness(0.6)"
          }}
        ></div>
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-2xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 leading-tight animate-fade-in text-white">
              {t('home.title')}
            </h1>
            <p className="text-xl md:text-2xl mb-8 text-white opacity-90 animate-slide-up">
              {t('home.subtitle')}
            </p>
            <Link 
              to="/preparedness" 
              className="inline-block bg-alert-500 hover:bg-alert-600 text-white py-3 px-8 rounded-md font-medium transition-all transform hover:scale-105 shadow-lg"
            >
              Learn More
            </Link>
          </div>
        </div>
      </section>

      {/* Emergency Alerts Section */}
      <section className="py-10 bg-alert-50">
        <div className="container mx-auto px-4">
          <div className="flex items-center mb-6">
            <AlertTriangle className="text-alert-500 w-6 h-6 mr-2" />
            <h2 className="text-2xl font-bold text-neutral-900">{t('home.alert.title')}</h2>
          </div>
          <div className="bg-white rounded-lg shadow-md p-6 border-l-4 border-alert-500 animate-pulse-slow">
            <h3 className="font-bold text-lg mb-2 text-alert-700">Monsoon Alert: June - October 2025</h3>
            <p className="mb-4 text-neutral-700">Heavy rainfall expected in the coming weeks. Be prepared for potential flooding in low-lying areas.</p>
            <button 
              onClick={getWeatherUpdates}
              className="text-primary-600 hover:text-primary-800 font-medium inline-flex items-center"
            >
              View latest weather updates <ChevronRight className="w-4 h-4 ml-1" />
            </button>
          </div>
        </div>
      </section>

      {/* Common Disasters Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12 text-neutral-900">
            {t('home.disasters.title')}
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {featuredDisasters.map((disaster) => (
              <Link 
                key={disaster.id}
                to={`/disasters/${disaster.id}`}
                className="card group bg-white overflow-hidden transform transition duration-300 hover:-translate-y-2"
              >
                <div className="relative h-48 overflow-hidden">
                  <img 
                    src={disaster.image} 
                    alt={disaster.title[language]} 
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                  <div 
                    className="absolute inset-0 opacity-50" 
                    style={{ backgroundColor: disaster.color }}
                  ></div>
                  <h3 className="absolute bottom-0 left-0 right-0 p-4 text-white text-xl font-bold">
                    {disaster.title[language]}
                  </h3>
                </div>
                <div className="p-6">
                  <p className="text-neutral-600 mb-4 line-clamp-3">
                    {disaster.description[language]}
                  </p>
                  <div className="flex items-center text-primary-600 font-medium">
                    Learn more <ChevronRight className="w-4 h-4 ml-1" />
                  </div>
                </div>
              </Link>
            ))}
          </div>
          <div className="text-center mt-10">
            <Link 
              to="/disasters" 
              className="inline-flex items-center justify-center bg-primary-500 hover:bg-primary-600 text-white py-2 px-6 rounded-md font-medium transition-all"
            >
              View all disaster types <ChevronRight className="w-4 h-4 ml-1" />
            </Link>
          </div>
        </div>
      </section>

      {/* Preparedness Guides */}
      <section className="py-16 bg-primary-50">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-center mb-12">
            <Shield className="text-safety-500 w-8 h-8 mr-3" />
            <h2 className="text-3xl font-bold text-neutral-900">
              {t('home.preparedness.title')}
            </h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bg-white rounded-lg shadow-md p-8 border-t-4 border-safety-500">
              <h3 className="text-xl font-bold mb-4 text-neutral-900">Emergency Kit Essentials</h3>
              <ul className="space-y-3 text-neutral-700">
                <li className="flex items-start">
                  <span className="inline-block w-2 h-2 bg-safety-500 rounded-full mt-2 mr-2"></span>
                  <span>Water (one gallon per person per day for at least three days)</span>
                </li>
                <li className="flex items-start">
                  <span className="inline-block w-2 h-2 bg-safety-500 rounded-full mt-2 mr-2"></span>
                  <span>Non-perishable food (at least a three-day supply)</span>
                </li>
                <li className="flex items-start">
                  <span className="inline-block w-2 h-2 bg-safety-500 rounded-full mt-2 mr-2"></span>
                  <span>Battery-powered radio and extra batteries</span>
                </li>
                <li className="flex items-start">
                  <span className="inline-block w-2 h-2 bg-safety-500 rounded-full mt-2 mr-2"></span>
                  <span>Flashlight and extra batteries</span>
                </li>
                <li className="flex items-start">
                  <span className="inline-block w-2 h-2 bg-safety-500 rounded-full mt-2 mr-2"></span>
                  <span>First aid kit and medications</span>
                </li>
              </ul>
              <Link 
                to="/resources" 
                className="inline-flex items-center mt-6 text-safety-600 hover:text-safety-700 font-medium"
              >
                Download complete checklist <ChevronRight className="w-4 h-4 ml-1" />
              </Link>
            </div>
            
            <div className="bg-white rounded-lg shadow-md p-8 border-t-4 border-safety-500">
              <h3 className="text-xl font-bold mb-4 text-neutral-900">Family Emergency Plan</h3>
              <ul className="space-y-3 text-neutral-700">
                <li className="flex items-start">
                  <span className="inline-block w-2 h-2 bg-safety-500 rounded-full mt-2 mr-2"></span>
                  <span>Identify evacuation routes from your home and neighborhood</span>
                </li>
                <li className="flex items-start">
                  <span className="inline-block w-2 h-2 bg-safety-500 rounded-full mt-2 mr-2"></span>
                  <span>Designate an emergency meeting place for your family</span>
                </li>
                <li className="flex items-start">
                  <span className="inline-block w-2 h-2 bg-safety-500 rounded-full mt-2 mr-2"></span>
                  <span>Choose an out-of-town contact person for coordination</span>
                </li>
                <li className="flex items-start">
                  <span className="inline-block w-2 h-2 bg-safety-500 rounded-full mt-2 mr-2"></span>
                  <span>Document important phone numbers and medical information</span>
                </li>
                <li className="flex items-start">
                  <span className="inline-block w-2 h-2 bg-safety-500 rounded-full mt-2 mr-2"></span>
                  <span>Practice your evacuation plan with all family members</span>
                </li>
              </ul>
              <Link 
                to="/preparedness" 
                className="inline-flex items-center mt-6 text-safety-600 hover:text-safety-700 font-medium"
              >
                Learn more about preparedness <ChevronRight className="w-4 h-4 ml-1" />
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Emergency Resources CTA */}
      <section className="py-16 bg-primary-700 text-white">
        <div className="container mx-auto px-4 text-center">
          <div className="flex flex-col md:flex-row items-center justify-center space-y-8 md:space-y-0 md:space-x-12">
            <div className="flex flex-col items-center">
              <BookOpen className="w-16 h-16 mb-4 text-primary-200" />
              <h3 className="text-2xl font-bold mb-2">Download Resources</h3>
              <p className="text-primary-100 mb-4 max-w-sm">
                Access our comprehensive collection of preparedness guides, checklists, and educational materials.
              </p>
              <Link 
                to="/resources" 
                className="btn btn-primary bg-white text-primary-700 hover:bg-primary-50"
              >
                View Resources
              </Link>
            </div>
            
            <div className="flex flex-col items-center">
              <Phone className="w-16 h-16 mb-4 text-primary-200" />
              <h3 className="text-2xl font-bold mb-2">Emergency Contacts</h3>
              <p className="text-primary-100 mb-4 max-w-sm">
                Find important emergency contact numbers for Hyderabad and surrounding areas.
              </p>
              <Link 
                to="/contacts" 
                className="btn btn-primary bg-white text-primary-700 hover:bg-primary-50"
              >
                View Contacts
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;