import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Header from './components/layout/Header';
import Footer from './components/layout/Footer';
import HomePage from './pages/HomePage';
import DisastersPage from './pages/DisastersPage';
import DisasterDetailPage from './pages/DisasterDetailPage';
import PreparednessPage from './pages/PreparednessPage';
import ResourcesPage from './pages/ResourcesPage';
import ContactsPage from './pages/ContactsPage';
import { LanguageProvider } from './contexts/LanguageContext';
import './App.css';

function App() {
  return (
    <LanguageProvider>
      <Router>
        <div className="flex flex-col min-h-screen">
          <Header />
          <main className="flex-grow">
            <Routes>
              <Route path="/" element={<HomePage />} />
              <Route path="/disasters" element={<DisastersPage />} />
              <Route path="/disasters/:disasterId" element={<DisasterDetailPage />} />
              <Route path="/preparedness" element={<PreparednessPage />} />
              <Route path="/resources" element={<ResourcesPage />} />
              <Route path="/contacts" element={<ContactsPage />} />
            </Routes>
          </main>
          <Footer />
        </div>
      </Router>
    </LanguageProvider>
  );
}

export default App;