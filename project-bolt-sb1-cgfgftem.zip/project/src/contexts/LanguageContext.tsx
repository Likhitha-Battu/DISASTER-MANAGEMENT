import React, { createContext, useState, useContext, ReactNode } from 'react';

type Language = 'en' | 'te';

interface LanguageContextType {
  language: Language;
  setLanguage: (language: Language) => void;
  t: (key: string) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

// This is a simplified translation function for demo purposes
// In a real app, you would use a more robust i18n solution
const translations: Record<Language, Record<string, string>> = {
  en: {
    // Header
    'site.title': 'Hyderabad Disaster Management',
    'nav.home': 'Home',
    'nav.disasters': 'Disasters',
    'nav.preparedness': 'Preparedness',
    'nav.resources': 'Resources',
    'nav.contacts': 'Emergency Contacts',
    'nav.risk': 'Risk Assessment',
    
    // Homepage
    'home.title': 'Be Prepared, Stay Safe',
    'home.subtitle': 'Your guide to disaster preparedness in Hyderabad',
    'home.cta': 'Assess Your Risk',
    'home.alert.title': 'Emergency Alerts',
    'home.disasters.title': 'Common Disasters',
    'home.preparedness.title': 'Preparedness Guides',
    'home.resources.title': 'Emergency Resources',
    
    // Disaster types
    'disaster.flood': 'Floods',
    'disaster.earthquake': 'Earthquakes',
    'disaster.heatwave': 'Heat Waves',
    'disaster.fire': 'Fires',
    'disaster.cyclone': 'Cyclones',
    
    // Footer
    'footer.disclaimer': 'This website provides information for disaster preparedness. In case of actual emergency, please contact official emergency services.',
    'footer.copyright': '© 2025 Hyderabad Disaster Management',
  },
  te: {
    // Header (Telugu translations)
    'site.title': 'హైదరాబాద్ విపత్తు నిర్వహణ',
    'nav.home': 'హోమ్',
    'nav.disasters': 'విపత్తులు',
    'nav.preparedness': 'సిద్ధత',
    'nav.resources': 'వనరులు',
    'nav.contacts': 'అత్యవసర సంప్రదింపులు',
    'nav.risk': 'రిస్క్ అసెస్మెంట్',
    
    // Homepage (Telugu translations)
    'home.title': 'సిద్ధంగా ఉండండి, సురక్షితంగా ఉండండి',
    'home.subtitle': 'హైదరాబాద్‌లో విపత్తు సిద్ధతకు మీ గైడ్',
    'home.cta': 'మీ రిస్క్‌ని అంచనా వేయండి',
    'home.alert.title': 'అత్యవసర హెచ్చరికలు',
    'home.disasters.title': 'సాధారణ విపత్తులు',
    'home.preparedness.title': 'సిద్ధత గైడ్‌లు',
    'home.resources.title': 'అత్యవసర వనరులు',
    
    // Disaster types (Telugu translations)
    'disaster.flood': 'వరదలు',
    'disaster.earthquake': 'భూకంపాలు',
    'disaster.heatwave': 'వేడి గాలులు',
    'disaster.fire': 'అగ్ని ప్రమాదాలు',
    'disaster.cyclone': 'తుఫానులు',
    
    // Footer (Telugu translations)
    'footer.disclaimer': 'ఈ వెబ్‌సైట్ విపత్తు సిద్ధత కోసం సమాచారాన్ని అందిస్తుంది. వాస్తవిక ఎమర్జెన్సీ సందర్భంలో, దయచేసి అధికారిక ఎమర్జెన్సీ సర్వీసులను సంప్రదించండి.',
    'footer.copyright': '© 2025 హైదరాబాద్ విపత్తు నిర్వహణ',
  }
};

export const LanguageProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [language, setLanguage] = useState<Language>('en');

  const t = (key: string): string => {
    return translations[language][key] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = (): LanguageContextType => {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};