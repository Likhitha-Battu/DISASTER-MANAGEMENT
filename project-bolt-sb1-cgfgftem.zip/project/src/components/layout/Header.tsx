import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, AlertTriangle, Globe } from 'lucide-react';
import { useLanguage } from '../../contexts/LanguageContext';

const Header: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [showAlert, setShowAlert] = useState(true);
  const { t, language, setLanguage } = useLanguage();
  const location = useLocation();

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const closeMenu = () => {
    setIsMenuOpen(false);
  };

  const toggleLanguage = () => {
    setLanguage(language === 'en' ? 'te' : 'en');
  };

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };

    window.addEventListener('scroll', handleScroll);
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  useEffect(() => {
    closeMenu();
  }, [location]);

  return (
    <header className="relative">
      {showAlert && (
        <div className="bg-alert-500 text-white py-2 px-4 flex justify-between items-center">
          <div className="flex items-center">
            <AlertTriangle className="w-4 h-4 mr-2" />
            <span className="text-sm">Monsoon season alert: Heavy rainfall expected. Stay prepared!</span>
          </div>
          <button 
            className="text-white hover:text-white/80"
            onClick={() => setShowAlert(false)}
            aria-label="Close alert"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      <nav 
        className={`py-4 px-6 transition-all duration-300 ${
          isScrolled ? 'bg-white shadow-md' : 'bg-transparent'
        }`}
      >
        <div className="container mx-auto flex justify-between items-center">
          <Link to="/" className="text-primary-700 font-bold text-xl">
            {t('site.title')}
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-6">
            <Link to="/" className="nav-link">
              {t('nav.home')}
            </Link>
            <Link to="/disasters" className="nav-link">
              {t('nav.disasters')}
            </Link>
            <Link to="/preparedness" className="nav-link">
              {t('nav.preparedness')}
            </Link>
            <Link to="/resources" className="nav-link">
              {t('nav.resources')}
            </Link>
            <Link to="/contacts" className="nav-link">
              {t('nav.contacts')}
            </Link>
            <button 
              onClick={toggleLanguage}
              className="flex items-center text-primary-600 hover:text-primary-800"
              aria-label="Toggle language"
            >
              <Globe className="w-5 h-5 mr-1" />
              <span className="text-sm font-medium">{language === 'en' ? 'తెలుగు' : 'English'}</span>
            </button>
          </div>

          {/* Mobile Menu Button */}
          <button 
            className="md:hidden text-primary-700"
            onClick={toggleMenu}
            aria-label="Toggle menu"
          >
            <Menu className="w-6 h-6" />
          </button>
        </div>

        {/* Mobile Navigation */}
        <div 
          className={`fixed inset-0 bg-white z-50 transform transition-transform duration-300 ${
            isMenuOpen ? 'translate-x-0' : 'translate-x-full'
          } md:hidden`}
        >
          <div className="flex justify-between items-center p-6 border-b">
            <Link to="/" className="text-primary-700 font-bold text-xl">
              {t('site.title')}
            </Link>
            <button 
              className="text-primary-700"
              onClick={toggleMenu}
              aria-label="Close menu"
            >
              <X className="w-6 h-6" />
            </button>
          </div>
          <div className="flex flex-col p-6 space-y-4">
            <Link to="/" className="text-neutral-800 py-2 border-b border-neutral-100">
              {t('nav.home')}
            </Link>
            <Link to="/disasters" className="text-neutral-800 py-2 border-b border-neutral-100">
              {t('nav.disasters')}
            </Link>
            <Link to="/preparedness" className="text-neutral-800 py-2 border-b border-neutral-100">
              {t('nav.preparedness')}
            </Link>
            <Link to="/resources" className="text-neutral-800 py-2 border-b border-neutral-100">
              {t('nav.resources')}
            </Link>
            <Link to="/contacts" className="text-neutral-800 py-2 border-b border-neutral-100">
              {t('nav.contacts')}
            </Link>
            <button 
              onClick={toggleLanguage}
              className="flex items-center justify-center text-primary-600 hover:text-primary-800 mt-4"
              aria-label="Toggle language"
            >
              <Globe className="w-5 h-5 mr-2" />
              <span>{language === 'en' ? 'తెలుగు' : 'English'}</span>
            </button>
          </div>
        </div>
      </nav>
    </header>
  );
};

export default Header;