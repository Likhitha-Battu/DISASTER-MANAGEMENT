import React from 'react';
import { Link } from 'react-router-dom';
import { Phone, Mail, MapPin, Facebook, Twitter, Instagram, Youtube } from 'lucide-react';
import { useLanguage } from '../../contexts/LanguageContext';

const Footer: React.FC = () => {
  const { t } = useLanguage();
  
  return (
    <footer className="bg-primary-800 text-white pt-12 pb-6">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <h3 className="text-xl font-bold mb-4">
              {t('site.title')}
            </h3>
            <p className="text-primary-100 mb-4">
              {t('footer.disclaimer')}
            </p>
            <div className="flex space-x-4">
              <a href="https://facebook.com" className="text-white hover:text-primary-200" aria-label="Facebook">
                <Facebook className="w-5 h-5" />
              </a>
              <a href="https://twitter.com" className="text-white hover:text-primary-200" aria-label="Twitter">
                <Twitter className="w-5 h-5" />
              </a>
              <a href="https://instagram.com" className="text-white hover:text-primary-200" aria-label="Instagram">
                <Instagram className="w-5 h-5" />
              </a>
              <a href="https://youtube.com" className="text-white hover:text-primary-200" aria-label="YouTube">
                <Youtube className="w-5 h-5" />
              </a>
            </div>
          </div>
          
          <div>
            <h4 className="font-bold mb-4">Quick Links</h4>
            <ul className="space-y-2">
              <li>
                <Link to="/" className="text-primary-100 hover:text-white transition">
                  {t('nav.home')}
                </Link>
              </li>
              <li>
                <Link to="/disasters" className="text-primary-100 hover:text-white transition">
                  {t('nav.disasters')}
                </Link>
              </li>
              <li>
                <Link to="/preparedness" className="text-primary-100 hover:text-white transition">
                  {t('nav.preparedness')}
                </Link>
              </li>
              <li>
                <Link to="/resources" className="text-primary-100 hover:text-white transition">
                  {t('nav.resources')}
                </Link>
              </li>
              <li>
                <Link to="/contacts" className="text-primary-100 hover:text-white transition">
                  {t('nav.contacts')}
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-bold mb-4">Emergency Numbers</h4>
            <ul className="space-y-2">
              <li className="flex items-center">
                <Phone className="w-4 h-4 mr-2" />
                <span>Emergency: 112</span>
              </li>
              <li className="flex items-center">
                <Phone className="w-4 h-4 mr-2" />
                <span>Police: 100</span>
              </li>
              <li className="flex items-center">
                <Phone className="w-4 h-4 mr-2" />
                <span>Fire: 101</span>
              </li>
              <li className="flex items-center">
                <Phone className="w-4 h-4 mr-2" />
                <span>Ambulance: 108</span>
              </li>
              <li className="flex items-center">
                <Phone className="w-4 h-4 mr-2" />
                <span>Disaster Management: 1077</span>
              </li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-bold mb-4">Contact Us</h4>
            <address className="not-italic">
              <div className="flex items-start mb-2">
                <MapPin className="w-4 h-4 mr-2 mt-1" />
                <span>Greater Hyderabad Municipal Corporation, Hyderabad, Telangana 500001</span>
              </div>
              <div className="flex items-center mb-2">
                <Mail className="w-4 h-4 mr-2" />
                <a href="mailto:info@hydisastermgmt.org" className="text-primary-100 hover:text-white">
                  info@hydisastermgmt.org
                </a>
              </div>
              <div className="flex items-center">
                <Phone className="w-4 h-4 mr-2" />
                <a href="tel:+914023454088" className="text-primary-100 hover:text-white">
                  +91 40 2345 4088
                </a>
              </div>
            </address>
          </div>
        </div>
        
        <div className="border-t border-primary-700 mt-8 pt-6 text-center text-primary-200 text-sm">
          <p>{t('footer.copyright')}</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;